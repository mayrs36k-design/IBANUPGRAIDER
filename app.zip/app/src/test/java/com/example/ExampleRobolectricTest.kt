package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.SoundEffects
import com.example.data.GameCatalog
import com.example.data.GameRepository
import com.example.model.Rarity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("IBAHURPGRAIDER", appName)
    }

    @Test
    fun `verify catalog cases are strictly ascending by price`() {
        assertTrue(GameCatalog.allCases.isNotEmpty())
        val prices = GameCatalog.allCases.map { it.price }
        val sortedPrices = prices.sorted()
        assertEquals("Кейсы должны быть строго отсортированы по возрастанию цены!", sortedPrices, prices)

        val firstCase = GameCatalog.allCases.first()
        assertEquals(29.0, firstCase.price, 0.01)
        assertTrue(firstCase.containedSkins.isNotEmpty())
    }

    @Test
    fun `verify every skin has its own unique distinct price`() {
        val allSkins = GameCatalog.allSkins
        assertTrue(allSkins.size >= 100)
        val uniquePrices = allSkins.map { it.price }.toSet()
        assertEquals("У каждого скина должна быть своя уникальная цена!", allSkins.size, uniquePrices.size)
    }

    @Test
    fun `verify case opening flow and balance`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val soundEffects = SoundEffects(context)
        val repository = GameRepository(context, soundEffects)

        val initialBalance = repository.profile.value.balance
        val testCase = GameCatalog.allCases.first()

        val wonSkins = repository.openCase(testCase, count = 2)
        assertEquals(2, wonSkins.size)

        val newBalance = repository.profile.value.balance
        assertEquals(initialBalance - (testCase.price * 2), newBalance, 0.01)

        val inventory = repository.inventory.value
        assertTrue(inventory.any { it.instanceId == wonSkins[0].instanceId })
        assertTrue(inventory.any { it.instanceId == wonSkins[1].instanceId })
    }

    @Test
    fun `verify upgrade mechanics`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val soundEffects = SoundEffects(context)
        val repository = GameRepository(context, soundEffects)

        val inventory = repository.inventory.value
        assertTrue(inventory.isNotEmpty())

        val inputSkin = inventory.first()
        val targetSkin = GameCatalog.allSkins.first { it.rarity == Rarity.SPECIAL }

        val result = repository.executeUpgrade(
            inputInstanceIds = listOf(inputSkin.instanceId),
            targetSkin = targetSkin,
            addedCash = 50.0
        )

        assertNotNull(result)
        assertTrue(result.odds in 0.01..0.85)
        if (result.success) {
            assertNotNull(result.wonSkin)
        } else {
            assertTrue(result.cashback > 0.0)
        }
    }

    @Test
    fun `verify farm clicker earning`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val soundEffects = SoundEffects(context)
        val repository = GameRepository(context, soundEffects)

        val balanceBefore = repository.profile.value.balance
        val earned = repository.clickFarm()
        val balanceAfter = repository.profile.value.balance

        assertEquals(balanceBefore + earned, balanceAfter, 0.01)
    }

    @Test
    fun `verify multi-account system creation and switching`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val soundEffects = SoundEffects(context)
        val repository = GameRepository(context, soundEffects)

        val initialAccountCount = repository.accounts.value.size
        assertTrue(initialAccountCount >= 1)

        val newAcc = repository.createAccount("ProPlayer", "avatars/0041b9003317b9a798e6c8169f8d5decd81b1cf5_full-extractpics.jpg", 7500.0)
        assertEquals("ProPlayer", newAcc.name)
        assertEquals(7500.0, newAcc.balance, 0.01)
        assertEquals(newAcc.id, repository.activeAccountId.value)
        assertEquals("ProPlayer", repository.profile.value.name)
        assertEquals(initialAccountCount + 1, repository.accounts.value.size)

        // Add bonus coins to this account
        repository.addBonusCoins(500.0)
        assertEquals(8000.0, repository.profile.value.balance, 0.01)

        // Switch back to first account
        val firstAcc = repository.accounts.value.first { it.id != newAcc.id }
        repository.switchAccount(firstAcc.id)
        assertEquals(firstAcc.id, repository.activeAccountId.value)
        assertEquals(firstAcc.name, repository.profile.value.name)

        // Delete created account
        val deleted = repository.deleteAccount(newAcc.id)
        assertTrue(deleted)
        assertEquals(initialAccountCount, repository.accounts.value.size)
    }

    @Test
    fun `verify offline mode toggle`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val soundEffects = SoundEffects(context)
        val repository = GameRepository(context, soundEffects)

        val initialOffline = repository.settings.value.isOfflineMode
        repository.setOfflineMode(!initialOffline)
        assertEquals(!initialOffline, repository.settings.value.isOfflineMode)

        // Toggle back
        repository.setOfflineMode(initialOffline)
        assertEquals(initialOffline, repository.settings.value.isOfflineMode)
    }

    @Test
    fun `verify all skins have real weapon photos and correct names`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val assetManager = context.assets

        for (skin in GameCatalog.allSkins) {
            assertTrue("Weapon name must be non-empty", skin.weaponName.isNotBlank())
            assertTrue("Skin name must be non-empty", skin.skinName.isNotBlank())

            val stream = assetManager.open(skin.assetPath)
            assertNotNull("Stream must not be null for ${skin.assetPath}", stream)
            assertTrue(stream.available() > 0)
            stream.close()

            assertTrue(!skin.assetPath.contains("cases/"))
            assertTrue(!skin.assetPath.contains("skin_137_"))
        }
    }
}
