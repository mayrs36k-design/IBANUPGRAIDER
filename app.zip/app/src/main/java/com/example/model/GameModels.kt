package com.example.model

import androidx.compose.ui.graphics.Color
import java.util.UUID

enum class Rarity(
    val title: String,
    val color: Color,
    val hexColor: Long,
    val dropWeight: Int
) {
    COMMON("Ширпотреб", Color(0xFFB0C3D9), 0xFFB0C3D9, 60),
    UNCOMMON("Промышленное", Color(0xFF5E98D9), 0xFF5E98D9, 35),
    MILSPEC("Армейское", Color(0xFF4B69FF), 0xFF4B69FF, 20),
    RESTRICTED("Запрещенное", Color(0xFF8847FF), 0xFF8847FF, 10),
    CLASSIFIED("Засекреченное", Color(0xFFD32CE6), 0xFFD32CE6, 4),
    COVERT("Тайное", Color(0xFFEB4B4B), 0xFFEB4B4B, 2),
    SPECIAL("Особо редкое ★", Color(0xFFFFD700), 0xFFFFD700, 1)
}

data class SkinItem(
    val id: String = UUID.randomUUID().toString(),
    val instanceId: String = UUID.randomUUID().toString(),
    val weaponName: String,
    val skinName: String,
    val rarity: Rarity,
    val price: Double,
    val assetPath: String,
    val isStatTrak: Boolean = false,
    val wear: String = "Прямо с завода"
) {
    val fullName: String
        get() = "${if (isStatTrak) "StatTrak™ " else ""}$weaponName | $skinName"

    val displayPrice: String
        get() = if (price >= 1000.0) {
            String.format("%,.0f ₽", price)
        } else {
            String.format("%.0f ₽", price)
        }
}

data class CaseItem(
    val id: String,
    val name: String,
    val category: String, // "Серийные", "Именные", "Футбольные", "Ножевые", "Лимитированные"
    val price: Double,
    val assetPath: String,
    val containedSkins: List<SkinItem>
) {
    val displayPrice: String
        get() = if (price >= 1000.0) {
            String.format("%,.0f ₽", price)
        } else {
            String.format("%.0f ₽", price)
        }

    val itemsCountText: String
        get() = "${containedSkins.size} предметов"
}

data class PlayerAccount(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Воробей",
    val avatarAsset: String = "avatars/0041b9003317b9a798e6c8169f8d5decd81b1cf5_full-extractpics.jpg",
    val balance: Double = 5000.0,
    val casesOpened: Int = 0,
    val upgradesTotal: Int = 0,
    val upgradesWon: Int = 0,
    val battlesWon: Int = 0,
    val contractsCompleted: Int = 0,
    val bestDrop: SkinItem? = null,
    val clickPower: Double = 1.0,
    val passiveIncomePerSec: Double = 0.0,
    val clickerCoinsTotal: Double = 0.0,
    val rankTitle: String = "Новичок Батлов",
    val inventory: List<SkinItem> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
) {
    val displayBalance: String
        get() = String.format("%.2f ₽", balance)
}

data class PlayerProfile(
    val accountId: String = UUID.randomUUID().toString(),
    val name: String = "Воробей",
    val avatarAsset: String = "avatars/0041b9003317b9a798e6c8169f8d5decd81b1cf5_full-extractpics.jpg",
    val balance: Double = 5000.0,
    val casesOpened: Int = 0,
    val upgradesTotal: Int = 0,
    val upgradesWon: Int = 0,
    val battlesWon: Int = 0,
    val contractsCompleted: Int = 0,
    val bestDrop: SkinItem? = null,
    val clickPower: Double = 1.0,
    val passiveIncomePerSec: Double = 0.0,
    val clickerCoinsTotal: Double = 0.0,
    val rankTitle: String = "Новичок Батлов"
) {
    val displayBalance: String
        get() = String.format("%.2f ₽", balance)
}

data class AppSettings(
    val isOfflineMode: Boolean = false,
    val isSoundEnabled: Boolean = true,
    val isHapticsEnabled: Boolean = true,
    val isFastRollDefault: Boolean = false
)

data class LiveDrop(
    val id: String = UUID.randomUUID().toString(),
    val userName: String,
    val avatarAsset: String,
    val skin: SkinItem,
    val caseName: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class BattleMode(val title: String, val description: String) {
    STANDARD("Классика", "Кто выбил дороже — забирает ВСЁ"),
    CRAZY("Крейзи мод", "Кто выбил ДЕШЕВЛЕ — забирает ВСЁ!")
}

enum class BattleDifficulty(val title: String, val botName: String, val winBonusMultiplier: Double) {
    EASY("Новичок", "Бот Сёма", 1.0),
    MEDIUM("Профи", "Снайпер_CS", 1.15),
    HARD("Олигарх", "Мусорный Барон", 1.35)
}

data class BattleRoundResult(
    val roundNumber: Int,
    val playerSkin: SkinItem,
    val botSkin: SkinItem
)

data class FarmUpgrade(
    val id: String,
    val title: String,
    val description: String,
    val cost: Double,
    val clickBonus: Double,
    val passiveBonus: Double,
    val level: Int = 0
) {
    val name: String
        get() = title

    val currentCost: Double
        get() = cost * (1.0 + level * 0.45)
}
