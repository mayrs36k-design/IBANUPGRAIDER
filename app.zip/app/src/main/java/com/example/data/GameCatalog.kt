package com.example.data

import com.example.model.CaseItem
import com.example.model.Rarity
import com.example.model.SkinItem

object GameCatalog {
    val allSkins: List<SkinItem> by lazy {
        listOf(
            // === ОСОБО РЕДКИЕ ★ И ТОПОВЫЕ СКИНЫ (ЦЕНЫ ДО 9 000 000 ₽) ===
            SkinItem(id = "skin_karambit_blue_gem", weaponName = "Керамбит", skinName = "Поверхностная закалка (Blue Gem #387)", rarity = Rarity.SPECIAL, price = 9000000.0, assetPath = "skins/730-karambit.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_gungnir_souvenir", weaponName = "AWP", skinName = "Гунгнир (Сувенирный)", rarity = Rarity.SPECIAL, price = 8950000.0, assetPath = "skins/awp_gungnir.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_butterfly_emerald", weaponName = "Нож-бабочка", skinName = "Волны Гамма Изумруд", rarity = Rarity.SPECIAL, price = 8400000.0, assetPath = "skins/730-butterfly-knife.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_gloves_vice_fn", weaponName = "Спортивные перчатки", skinName = "Порок (Vice)", rarity = Rarity.SPECIAL, price = 7800000.0, assetPath = "skins/730-sport-gloves.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_wild_lotus_st", weaponName = "AK-47", skinName = "Дикий лотос (Wild Lotus)", rarity = Rarity.SPECIAL, price = 7200000.0, assetPath = "skins/ak47_wild_lotus.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_m9_crimson_st", weaponName = "Штык-нож M9", skinName = "Кровавая паутина", rarity = Rarity.SPECIAL, price = 6500000.0, assetPath = "skins/730-m9-bayonet.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_talon_sapphire", weaponName = "Нож Коготь", skinName = "Волны Сапфир", rarity = Rarity.SPECIAL, price = 5800000.0, assetPath = "skins/730-talon-knife.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_skeleton_fade_max", weaponName = "Скелетный нож", skinName = "Градиент 100% Fade", rarity = Rarity.SPECIAL, price = 5200000.0, assetPath = "skins/730-skeleton-knife.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_kukri_crimson_st", weaponName = "Нож Кукри", skinName = "Кровавая паутина", rarity = Rarity.SPECIAL, price = 4600000.0, assetPath = "skins/kukri_knife.png", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_gloves_hedge_maze", weaponName = "Спортивные перчатки", skinName = "Живая изгородь", rarity = Rarity.SPECIAL, price = 4100000.0, assetPath = "skins/gloves_hedge_maze.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_driver_king_snake", weaponName = "Перчатки водителя", skinName = "Королевский змей", rarity = Rarity.SPECIAL, price = 3600000.0, assetPath = "skins/730-driver-gloves.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_flip_sapphire", weaponName = "Складной нож", skinName = "Волны Сапфир", rarity = Rarity.SPECIAL, price = 3200000.0, assetPath = "skins/knife_flip_sapphire.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_flip_ruby", weaponName = "Складной нож", skinName = "Волны Рубин", rarity = Rarity.SPECIAL, price = 2850000.0, assetPath = "skins/knife_flip_ruby.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_howl_charm", weaponName = "M4A4", skinName = "Вой (Hot Howl)", rarity = Rarity.SPECIAL, price = 2500000.0, assetPath = "skins/730-charm-hot-howl.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_specialist_marble", weaponName = "Перчатки «Специалист»", skinName = "Мраморный градиент", rarity = Rarity.SPECIAL, price = 2200000.0, assetPath = "skins/730-specialist-gloves.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ursus_marble", weaponName = "Нож Медведь", skinName = "Волны Сапфир", rarity = Rarity.SPECIAL, price = 1950000.0, assetPath = "skins/730-ursus-knife.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_stiletto_tiger", weaponName = "Стилет", skinName = "Зуб тигра", rarity = Rarity.SPECIAL, price = 1700000.0, assetPath = "skins/730-stiletto-knife.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_fade_st", weaponName = "AWP", skinName = "Градиент", rarity = Rarity.SPECIAL, price = 1450000.0, assetPath = "skins/730-awp-fade-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_nomad_slaughter", weaponName = "Нож Бродяга", skinName = "Убийство", rarity = Rarity.SPECIAL, price = 1250000.0, assetPath = "skins/730-nomad-knife.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_gloves_moto_blood", weaponName = "Мотоциклетные перчатки", skinName = "Кровяное давление", rarity = Rarity.SPECIAL, price = 1100000.0, assetPath = "skins/gloves_moto_blood.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_paracord_slaughter", weaponName = "Нож с паракордом", skinName = "Градиент", rarity = Rarity.SPECIAL, price = 950000.0, assetPath = "skins/730-paracord-knife.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_classic_fade", weaponName = "Классический нож", skinName = "Градиент", rarity = Rarity.SPECIAL, price = 820000.0, assetPath = "skins/730-classic-knife.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_gloves_specialist_emerald", weaponName = "Перчатки «Специалист»", skinName = "Изумрудная паутина", rarity = Rarity.SPECIAL, price = 720000.0, assetPath = "skins/gloves_specialist_emerald.webp", isStatTrak = false, wear = "После полевых испытаний"),
            SkinItem(id = "skin_bayonet_crimson", weaponName = "Штык-нож", skinName = "Кровавая паутина", rarity = Rarity.SPECIAL, price = 640000.0, assetPath = "skins/knife_bayonet_crimson.webp", isStatTrak = true, wear = "Немного поношенное"),
            SkinItem(id = "skin_falchion_case_hardened", weaponName = "Фальшион", skinName = "Поверхностная закалка", rarity = Rarity.SPECIAL, price = 550000.0, assetPath = "skins/730-falchion-knife.webp", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_survival_crimson", weaponName = "Нож выживания", skinName = "Кровавая паутина", rarity = Rarity.SPECIAL, price = 480000.0, assetPath = "skins/730-survival-knife.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_bowie_lore", weaponName = "Нож Боуи", skinName = "Легенды", rarity = Rarity.SPECIAL, price = 410000.0, assetPath = "skins/730-bowie-knife.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m9_night", weaponName = "Штык-нож M9", skinName = "Ночь", rarity = Rarity.SPECIAL, price = 350000.0, assetPath = "skins/knife_m9_night.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_flip_blue_steel", weaponName = "Складной нож", skinName = "Вороненая сталь", rarity = Rarity.SPECIAL, price = 290000.0, assetPath = "skins/knife_flip_blue_steel.png", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_gut_autotronic", weaponName = "Нож с лезвием-крюком", skinName = "Автотроника", rarity = Rarity.SPECIAL, price = 240000.0, assetPath = "skins/730-gut-knife.webp", isStatTrak = false, wear = "После полевых испытаний"),
            SkinItem(id = "skin_shadow_daggers", weaponName = "Тычковые ножи", skinName = "Зуб тигра", rarity = Rarity.SPECIAL, price = 195000.0, assetPath = "skins/knife_shadow_daggers.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_navaja_case", weaponName = "Нож Наваха", skinName = "Поверхностная закалка", rarity = Rarity.SPECIAL, price = 160000.0, assetPath = "skins/730-navaja-knife.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_gloves_imperial_plaid", weaponName = "Перчатки водителя", skinName = "Имперская клетка", rarity = Rarity.SPECIAL, price = 135000.0, assetPath = "skins/gloves_imperial_plaid.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_gloves_moto_finish", weaponName = "Мотоциклетные перчатки", skinName = "Финишная прямая", rarity = Rarity.SPECIAL, price = 115000.0, assetPath = "skins/730-moto-gloves.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_hydra_emerald", weaponName = "Перчатки «Гидра»", skinName = "Изумруд", rarity = Rarity.SPECIAL, price = 98000.0, assetPath = "skins/730-hydra-gloves.webp", isStatTrak = false, wear = "После полевых испытаний"),
            SkinItem(id = "skin_broken_fang_unhinged", weaponName = "Перчатки «Сломанный клык»", skinName = "Без тормозов", rarity = Rarity.SPECIAL, price = 84000.0, assetPath = "skins/730-broken-fang-gloves.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_bloodhound_bronzed", weaponName = "Перчатки «Ищейка»", skinName = "Бронза", rarity = Rarity.SPECIAL, price = 72000.0, assetPath = "skins/730-bloodhound-gloves.webp", isStatTrak = false, wear = "После полевых испытаний"),
            SkinItem(id = "skin_knife_rare_gold", weaponName = "★ Редкий особый предмет ★", skinName = "Золотой нож", rarity = Rarity.SPECIAL, price = 65000.0, assetPath = "skins/knife_rare_special.png", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_skeleton_forest", weaponName = "Скелетный нож", skinName = "Камуфляж «Лес»", rarity = Rarity.SPECIAL, price = 58000.0, assetPath = "skins/knife_skeleton_forest.png", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_flip_stained", weaponName = "Складной нож", skinName = "Патина", rarity = Rarity.SPECIAL, price = 52000.0, assetPath = "skins/knife_flip_stained.png", isStatTrak = false, wear = "Немного поношенное"),

            // === ТАЙНОЕ (COVERT) ===
            SkinItem(id = "skin_m4a1s_blue_phosphor", weaponName = "M4A1-S", skinName = "Синий фосфор", rarity = Rarity.COVERT, price = 480000.0, assetPath = "skins/730-m4a1-s-blue-phosphor-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_aphrodite", weaponName = "AK-47", skinName = "Афродита", rarity = Rarity.COVERT, price = 390000.0, assetPath = "skins/730-ak-47-aphrodite-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_asiimov", weaponName = "AWP", skinName = "Азимов", rarity = Rarity.COVERT, price = 320000.0, assetPath = "skins/730-awp-asiimov-field-tested.webp", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_ak47_breakthrough", weaponName = "AK-47", skinName = "Прорыв", rarity = Rarity.COVERT, price = 260000.0, assetPath = "skins/730-ak-47-breakthrough-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_emperor", weaponName = "M4A4", skinName = "Император", rarity = Rarity.COVERT, price = 210000.0, assetPath = "skins/730-m4a4-the-emperor-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_graphite", weaponName = "AWP", skinName = "Графит", rarity = Rarity.COVERT, price = 175000.0, assetPath = "skins/awp_graphite.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_fuel_injector", weaponName = "AK-47", skinName = "Топливный инжектор", rarity = Rarity.COVERT, price = 145000.0, assetPath = "skins/ak47_fuel_injector.png", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_deagle_crimson_web", weaponName = "Desert Eagle", skinName = "Кровавая паутина", rarity = Rarity.COVERT, price = 125000.0, assetPath = "skins/730-desert-eagle-crimson-web-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_royal_paladin", weaponName = "M4A4", skinName = "Королевский паладин", rarity = Rarity.COVERT, price = 105000.0, assetPath = "skins/730-m4a4-royal-paladin-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_emerald_dragon", weaponName = "P90", skinName = "Изумрудный дракон", rarity = Rarity.COVERT, price = 88000.0, assetPath = "skins/p90_emerald_dragon.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_wildfire", weaponName = "AWP", skinName = "Дикое пламя", rarity = Rarity.COVERT, price = 74000.0, assetPath = "skins/awp_wildfire.png", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_deagle_ocean_drive", weaponName = "Desert Eagle", skinName = "Океанское побережье", rarity = Rarity.COVERT, price = 62000.0, assetPath = "skins/deagle_ocean_drive.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_awp_hyper_beast", weaponName = "AWP", skinName = "Скоростной зверь", rarity = Rarity.COVERT, price = 53000.0, assetPath = "skins/awp_hyper_beast.png", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_awp_exothermic", weaponName = "AWP", skinName = "Экзотермик", rarity = Rarity.COVERT, price = 45000.0, assetPath = "skins/730-awp-exothermic-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_jaguar", weaponName = "AK-47", skinName = "Ягуар", rarity = Rarity.COVERT, price = 38000.0, assetPath = "skins/ak47_jaguar.png", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_in_living_color", weaponName = "M4A4", skinName = "В живом цвете", rarity = Rarity.COVERT, price = 32000.0, assetPath = "skins/730-m4a4-in-living-color-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_queen_gambit", weaponName = "AWP", skinName = "Ферзевый гамбит", rarity = Rarity.COVERT, price = 27000.0, assetPath = "skins/730-awp-queen-s-gambit-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_deagle_cobalt_disruption", weaponName = "Desert Eagle", skinName = "Кобальтовая буря", rarity = Rarity.COVERT, price = 23000.0, assetPath = "skins/730-desert-eagle-cobalt-disruption-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_water_elemental", weaponName = "Glock-18", skinName = "Дух воды", rarity = Rarity.COVERT, price = 19500.0, assetPath = "skins/730-glock-18-water-elemental-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_daybreak", weaponName = "M4A4", skinName = "Рассвет", rarity = Rarity.COVERT, price = 16800.0, assetPath = "skins/730-m4a4-daybreak-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_deagle_kumicho_dragon", weaponName = "Desert Eagle", skinName = "Дракон-предводитель", rarity = Rarity.COVERT, price = 14500.0, assetPath = "skins/730-desert-eagle-kumicho-dragon-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_usp_cortex", weaponName = "USP-S", skinName = "Извилины", rarity = Rarity.COVERT, price = 12800.0, assetPath = "skins/730-usp-s-cortex-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_bullet_queen", weaponName = "Glock-18", skinName = "Королева пуль", rarity = Rarity.COVERT, price = 11200.0, assetPath = "skins/glock_bullet_queen.webp", isStatTrak = true, wear = "Немного поношенное"),
            SkinItem(id = "skin_awp_neo_noir", weaponName = "AWP", skinName = "Нео-нуар", rarity = Rarity.COVERT, price = 9800.0, assetPath = "skins/awp_neo_noir.png", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_sheet_lightning", weaponName = "M4A4", skinName = "Зарница", rarity = Rarity.COVERT, price = 8500.0, assetPath = "skins/730-m4a4-sheet-lightning-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_asiimov", weaponName = "P90", skinName = "Азимов", rarity = Rarity.COVERT, price = 7400.0, assetPath = "skins/p90_asiimov.png", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_awp_the_end", weaponName = "AWP", skinName = "Конец", rarity = Rarity.COVERT, price = 6500.0, assetPath = "skins/730-awp-the-end-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_five_seven_angry_mob", weaponName = "Five-SeVeN", skinName = "Разъяренная толпа", rarity = Rarity.COVERT, price = 5700.0, assetPath = "skins/730-five-seven-angry-mob-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_deathgaze", weaponName = "P90", skinName = "Смертельный взгляд", rarity = Rarity.COVERT, price = 4900.0, assetPath = "skins/730-p90-deathgaze-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_fever_dream", weaponName = "AWP", skinName = "Горячечные грезы", rarity = Rarity.COVERT, price = 4200.0, assetPath = "skins/awp_fever_dream.png", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_zubastick", weaponName = "M4A4", skinName = "Зубастик", rarity = Rarity.COVERT, price = 3800.0, assetPath = "skins/730-m4a4-zubastick-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),

            // === ЗАСЕКРЕЧЕННОЕ (CLASSIFIED) ===
            SkinItem(id = "skin_m4a1s_icarus_fell", weaponName = "M4A1-S", skinName = "Падение Икара", rarity = Rarity.CLASSIFIED, price = 35000.0, assetPath = "skins/m4a1s_icarus_fell.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp9_wild_lily", weaponName = "MP9", skinName = "Дикая лилия", rarity = Rarity.CLASSIFIED, price = 31000.0, assetPath = "skins/730-mp9-wild-lily-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a1s_nightmare", weaponName = "M4A1-S", skinName = "Ночной кошмар", rarity = Rarity.CLASSIFIED, price = 18500.0, assetPath = "skins/730-m4a1-s-nightmare-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_crane_flight", weaponName = "AK-47", skinName = "Полет журавля", rarity = Rarity.CLASSIFIED, price = 15000.0, assetPath = "skins/730-ak-47-crane-flight-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a1s_glitched_paint", weaponName = "M4A1-S", skinName = "Глитч", rarity = Rarity.CLASSIFIED, price = 12000.0, assetPath = "skins/730-m4a1-s-glitched-paint-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_usp_monster_mashup", weaponName = "USP-S", skinName = "Чудовищная смесь", rarity = Rarity.CLASSIFIED, price = 10500.0, assetPath = "skins/730-usp-s-monster-mashup-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_vogue", weaponName = "Glock-18", skinName = "Мода", rarity = Rarity.CLASSIFIED, price = 9200.0, assetPath = "skins/730-glock-18-vogue-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_agent_ava", weaponName = "Агент FBI", skinName = "Специальный агент Ава", rarity = Rarity.CLASSIFIED, price = 8500.0, assetPath = "skins/agent_fbi_ava.webp", isStatTrak = false, wear = "Мастер"),
            SkinItem(id = "skin_awp_phobos", weaponName = "AWP", skinName = "Фобос", rarity = Rarity.CLASSIFIED, price = 7800.0, assetPath = "skins/730-awp-phobos-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_agent_mae", weaponName = "Агент SWAT", skinName = "Командир Мэй", rarity = Rarity.CLASSIFIED, price = 7200.0, assetPath = "skins/agent_swat_mae.webp", isStatTrak = false, wear = "Мастер"),
            SkinItem(id = "skin_scar20_bloodsport", weaponName = "SCAR-20", skinName = "Кровавый спорт", rarity = Rarity.CLASSIFIED, price = 6500.0, assetPath = "skins/730-scar-20-bloodsport-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_aeolian_dark", weaponName = "M4A4", skinName = "Эолийская тьма", rarity = Rarity.CLASSIFIED, price = 5900.0, assetPath = "skins/730-m4a4-aeolian-dark-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_buzz_kill", weaponName = "M4A4", skinName = "Обжорка", rarity = Rarity.CLASSIFIED, price = 5400.0, assetPath = "skins/m4a4_buzz_kill.png", isStatTrak = true, wear = "Немного поношенное"),
            SkinItem(id = "skin_m4a1s_electrum", weaponName = "M4A1-S", skinName = "Электрум", rarity = Rarity.CLASSIFIED, price = 4900.0, assetPath = "skins/730-m4a1-s-electrum-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_galil_sugar_rush", weaponName = "Galil AR", skinName = "Сахарная лихорадка", rarity = Rarity.CLASSIFIED, price = 4500.0, assetPath = "skins/730-galil-ar-sugar-rush-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_man_o_war", weaponName = "AWP", skinName = "Морской шторм", rarity = Rarity.CLASSIFIED, price = 4200.0, assetPath = "skins/awp_man_o_war.webp", isStatTrak = false, wear = "После полевых испытаний"),
            SkinItem(id = "skin_ssg08_death_strike", weaponName = "SSG 08", skinName = "Смертельный удар", rarity = Rarity.CLASSIFIED, price = 3900.0, assetPath = "skins/730-ssg-08-death-strike-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_sun_in_leo", weaponName = "AWP", skinName = "Солнце в знаке Льва", rarity = Rarity.CLASSIFIED, price = 3650.0, assetPath = "skins/awp_sun_in_leo.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_nostalgia", weaponName = "P90", skinName = "Ностальгия", rarity = Rarity.CLASSIFIED, price = 3400.0, assetPath = "skins/730-p90-nostalgia-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_cartel", weaponName = "AK-47", skinName = "Картель", rarity = Rarity.CLASSIFIED, price = 3200.0, assetPath = "skins/ak47_cartel.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_deagle_oxide_blaze", weaponName = "Desert Eagle", skinName = "Оксидное пламя", rarity = Rarity.CLASSIFIED, price = 3000.0, assetPath = "skins/730-desert-eagle-oxide-blaze-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_duality", weaponName = "AWP", skinName = "Двойственность", rarity = Rarity.CLASSIFIED, price = 2800.0, assetPath = "skins/awp_duality.webp", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_pp_bizon_traitor", weaponName = "ПП-19 Бизон", skinName = "Предатель", rarity = Rarity.CLASSIFIED, price = 2600.0, assetPath = "skins/730-pp-bizon-traitor-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_rat_rod", weaponName = "AK-47", skinName = "Колымага", rarity = Rarity.CLASSIFIED, price = 2400.0, assetPath = "skins/ak47_rat_rod.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p250_see_ya_later", weaponName = "P250", skinName = "До скорого", rarity = Rarity.CLASSIFIED, price = 2200.0, assetPath = "skins/730-p250-see-ya-later-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_galil_chromatic", weaponName = "Galil AR", skinName = "Хроматическая аберрация", rarity = Rarity.CLASSIFIED, price = 2050.0, assetPath = "skins/galil_chromatic.webp", isStatTrak = true, wear = "Немного поношенное"),
            SkinItem(id = "skin_m4a4_converter", weaponName = "M4A4", skinName = "Преобразователь", rarity = Rarity.CLASSIFIED, price = 1900.0, assetPath = "skins/730-m4a4-converter-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_cz75_chalice", weaponName = "CZ75-Auto", skinName = "Чаша", rarity = Rarity.CLASSIFIED, price = 1750.0, assetPath = "skins/730-cz75-auto-chalice-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_nuclear_garden", weaponName = "Glock-18", skinName = "Ядерный сад", rarity = Rarity.CLASSIFIED, price = 1600.0, assetPath = "skins/glock_nuclear_garden.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ssg08_bloodshot", weaponName = "SSG 08", skinName = "Кровь в глазах", rarity = Rarity.CLASSIFIED, price = 1450.0, assetPath = "skins/730-ssg-08-bloodshot-minimal-wear.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_ump45_warm_blooded", weaponName = "UMP-45", skinName = "Теплокровный", rarity = Rarity.CLASSIFIED, price = 1300.0, assetPath = "skins/730-ump-45-warm-blooded-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_capsule_stockholm", weaponName = "Капсула с наклейками", skinName = "Претенденты Стокгольм", rarity = Rarity.CLASSIFIED, price = 1200.0, assetPath = "skins/capsule_contenders_stockholm.webp", isStatTrak = false, wear = "Особая"),

            // === ЗАПРЕЩЕННОЕ (RESTRICTED) ===
            SkinItem(id = "skin_ak47_elite_build", weaponName = "AK-47", skinName = "Элитное снаряжение", rarity = Rarity.RESTRICTED, price = 2800.0, assetPath = "skins/730-ak-47-elite-build-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_moonrise", weaponName = "Glock-18", skinName = "Восход луны", rarity = Rarity.RESTRICTED, price = 2400.0, assetPath = "skins/730-glock-18-moonrise-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mac10_graven", weaponName = "MAC-10", skinName = "Гравюра", rarity = Rarity.RESTRICTED, price = 2150.0, assetPath = "skins/730-mac-10-graven-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a1s_briefing", weaponName = "M4A1-S", skinName = "Инструктаж", rarity = Rarity.RESTRICTED, price = 1950.0, assetPath = "skins/730-m4a1-s-briefing-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_wintergreen", weaponName = "AK-47", skinName = "Зимняя мята", rarity = Rarity.RESTRICTED, price = 1750.0, assetPath = "skins/730-ak-47-wintergreen-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_tiger_pit", weaponName = "P90", skinName = "Тигриная яма", rarity = Rarity.RESTRICTED, price = 1600.0, assetPath = "skins/730-p90-tiger-pit-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp7_skulls", weaponName = "MP7", skinName = "Черепа", rarity = Rarity.RESTRICTED, price = 1500.0, assetPath = "skins/730-mp7-skulls-minimal-wear.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_ak47_slate", weaponName = "AK-47", skinName = "Сланец", rarity = Rarity.RESTRICTED, price = 1400.0, assetPath = "skins/ak47_slate.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_galil_sky_mandala", weaponName = "Galil AR", skinName = "Небесная мандала", rarity = Rarity.RESTRICTED, price = 1300.0, assetPath = "skins/730-galil-ar-sky-mandala-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p250_bengal_tiger", weaponName = "P250", skinName = "Бенгальский тигр", rarity = Rarity.RESTRICTED, price = 1200.0, assetPath = "skins/730-p250-bengal-tiger-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_aug_carved_jade", weaponName = "AUG", skinName = "Резной нефрит", rarity = Rarity.RESTRICTED, price = 1100.0, assetPath = "skins/730-aug-carved-jade-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_deagle_conspiracy", weaponName = "Desert Eagle", skinName = "Заговор", rarity = Rarity.RESTRICTED, price = 1000.0, assetPath = "skins/deagle_conspiracy.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_ump45_exposure", weaponName = "UMP-45", skinName = "Экспозиция", rarity = Rarity.RESTRICTED, price = 920.0, assetPath = "skins/730-ump-45-exposure-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_scar20_cyrex", weaponName = "SCAR-20", skinName = "Сайрекс", rarity = Rarity.RESTRICTED, price = 850.0, assetPath = "skins/730-scar-20-cyrex-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp9_whiteout", weaponName = "MP9", skinName = "Белая мгла", rarity = Rarity.RESTRICTED, price = 800.0, assetPath = "skins/mp9_whiteout.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp9_cobalt_paisley", weaponName = "MP9", skinName = "Кобальтовый узор", rarity = Rarity.RESTRICTED, price = 750.0, assetPath = "skins/730-mp9-cobalt-paisley-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a1s_night_terror", weaponName = "M4A1-S", skinName = "Ночной кошмар", rarity = Rarity.RESTRICTED, price = 700.0, assetPath = "skins/m4a1s_night_terror.webp", isStatTrak = false, wear = "После полевых испытаний"),
            SkinItem(id = "skin_mp5_oxide_oasis", weaponName = "MP5-SD", skinName = "Оазис оксидов", rarity = Rarity.RESTRICTED, price = 660.0, assetPath = "skins/730-mp5-sd-oxide-oasis-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_coral_bloom", weaponName = "Glock-18", skinName = "Коралловый расцвет", rarity = Rarity.RESTRICTED, price = 620.0, assetPath = "skins/730-glock-18-coral-bloom-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mac10_pipe_down", weaponName = "MAC-10", skinName = "Сбавь обороты", rarity = Rarity.RESTRICTED, price = 580.0, assetPath = "skins/730-mac-10-pipe-down-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_famas_sundown", weaponName = "FAMAS", skinName = "Закат", rarity = Rarity.RESTRICTED, price = 540.0, assetPath = "skins/730-famas-sundown-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_tec9_banana_leaf", weaponName = "TEC-9", skinName = "Банановый лист", rarity = Rarity.RESTRICTED, price = 500.0, assetPath = "skins/730-tec-9-banana-leaf-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_awp_pit_viper", weaponName = "AWP", skinName = "Гадюка", rarity = Rarity.RESTRICTED, price = 470.0, assetPath = "skins/awp_pit_viper.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_ak47_varicamo", weaponName = "AK-47", skinName = "Серый камуфляж", rarity = Rarity.RESTRICTED, price = 440.0, assetPath = "skins/730-ak-47-varicamo-grey-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_ghost_protocol", weaponName = "Glock-18", skinName = "Протокол «Призрак»", rarity = Rarity.RESTRICTED, price = 410.0, assetPath = "skins/730-glock-18-ghost-protocol-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_aug_arctic_wolf", weaponName = "AUG", skinName = "Арктический волк", rarity = Rarity.RESTRICTED, price = 380.0, assetPath = "skins/730-aug-arctic-wolf-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_usp_blueprint", weaponName = "USP-S", skinName = "Калька", rarity = Rarity.RESTRICTED, price = 350.0, assetPath = "skins/730-usp-s-blueprint-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),

            // === АРМЕЙСКОЕ (MIL-SPEC) И ДЕШЕВЫЕ СКИНЫ (ОСТАЮТСЯ ДОСТУПНЫМИ ДЛЯ СТАРТА) ===
            SkinItem(id = "skin_m4a4_desert_storm", weaponName = "M4A4", skinName = "Буря в пустыне", rarity = Rarity.MILSPEC, price = 320.0, assetPath = "skins/730-m4a4-desert-storm-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp7_amberline", weaponName = "MP7", skinName = "Янтарная линия", rarity = Rarity.MILSPEC, price = 290.0, assetPath = "skins/730-mp7-amberline-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_mustard_gas", weaponName = "P90", skinName = "Иприт", rarity = Rarity.MILSPEC, price = 270.0, assetPath = "skins/730-p90-mustard-gas-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_ssg08_green_ceramic", weaponName = "SSG 08", skinName = "Зеленая керамика", rarity = Rarity.MILSPEC, price = 250.0, assetPath = "skins/730-ssg-08-green-ceramic-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp5_picnic", weaponName = "MP5-SD", skinName = "Пикник", rarity = Rarity.MILSPEC, price = 230.0, assetPath = "skins/730-mp5-sd-picnic-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_pp_bizon_rmx", weaponName = "ПП-19 Бизон", skinName = "RMX", rarity = Rarity.MILSPEC, price = 210.0, assetPath = "skins/730-pp-bizon-rmx-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_ump45_fragment", weaponName = "UMP-45", skinName = "Осколок", rarity = Rarity.MILSPEC, price = 190.0, assetPath = "skins/730-ump-45-fragment-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_pink_ddpat", weaponName = "Glock-18", skinName = "Розовый DDPAT", rarity = Rarity.MILSPEC, price = 180.0, assetPath = "skins/730-glock-18-pink-ddpat-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_ak47_predator", weaponName = "AK-47", skinName = "Хищник", rarity = Rarity.MILSPEC, price = 170.0, assetPath = "skins/ak47_predator.webp", isStatTrak = false, wear = "Немного поношенное"),
            SkinItem(id = "skin_deagle_bronze", weaponName = "Desert Eagle", skinName = "Бронза", rarity = Rarity.MILSPEC, price = 160.0, assetPath = "skins/730-desert-eagle-the-bronze-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp9_urban_sovereign", weaponName = "MP9", skinName = "Городской монарх", rarity = Rarity.MILSPEC, price = 150.0, assetPath = "skins/730-mp9-urban-sovereign-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_scar20_fragments", weaponName = "SCAR-20", skinName = "Фрагменты", rarity = Rarity.MILSPEC, price = 140.0, assetPath = "skins/730-scar-20-fragments-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_tec9_blue_blast", weaponName = "TEC-9", skinName = "Синий взрыв", rarity = Rarity.MILSPEC, price = 130.0, assetPath = "skins/730-tec-9-blue-blast-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_attack_vector", weaponName = "P90", skinName = "Вектор атаки", rarity = Rarity.MILSPEC, price = 120.0, assetPath = "skins/730-p90-attack-vector-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_m4a4_magnesium", weaponName = "M4A4", skinName = "Магний", rarity = Rarity.MILSPEC, price = 110.0, assetPath = "skins/m4a4_magnesium.webp", isStatTrak = true, wear = "После полевых испытаний"),
            SkinItem(id = "skin_sg553_cyberforce", weaponName = "SG 553", skinName = "Киберсила", rarity = Rarity.MILSPEC, price = 100.0, assetPath = "skins/730-sg-553-cyberforce-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_five_seven_sky_blue", weaponName = "Five-SeVeN", skinName = "Голубое небо", rarity = Rarity.MILSPEC, price = 95.0, assetPath = "skins/730-five-seven-sky-blue-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_famas_byproduct", weaponName = "FAMAS", skinName = "Побочный продукт", rarity = Rarity.MILSPEC, price = 90.0, assetPath = "skins/730-famas-byproduct-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_mac10_button_masher", weaponName = "MAC-10", skinName = "Кнопочный машер", rarity = Rarity.MILSPEC, price = 85.0, assetPath = "skins/730-mac-10-button-masher-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_scar20_jungle", weaponName = "SCAR-20", skinName = "Зеленый камуфляж", rarity = Rarity.MILSPEC, price = 80.0, assetPath = "skins/scar20_jungle.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ump45_riot", weaponName = "UMP-45", skinName = "Бунт", rarity = Rarity.MILSPEC, price = 75.0, assetPath = "skins/730-ump-45-riot-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_glock_brass", weaponName = "Glock-18", skinName = "Латунь", rarity = Rarity.MILSPEC, price = 70.0, assetPath = "skins/730-glock-18-brass-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_pp_bizon_bizoom", weaponName = "ПП-19 Бизон", skinName = "Бизум", rarity = Rarity.MILSPEC, price = 65.0, assetPath = "skins/730-pp-bizon-bizoom-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p2000_coach_class", weaponName = "P2000", skinName = "Туристический класс", rarity = Rarity.MILSPEC, price = 60.0, assetPath = "skins/730-p2000-coach-class-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp5_focus", weaponName = "MP5-SD", skinName = "Фокус", rarity = Rarity.MILSPEC, price = 55.0, assetPath = "skins/730-mp5-sd-focus-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_aug_amber_slipstream", weaponName = "AUG", skinName = "Янтарный вихрь", rarity = Rarity.MILSPEC, price = 50.0, assetPath = "skins/730-aug-amber-slipstream-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ssg08_calligrafaux", weaponName = "SSG 08", skinName = "Каллиграфия", rarity = Rarity.MILSPEC, price = 48.0, assetPath = "skins/730-ssg-08-calligrafaux-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_ump45_corporal", weaponName = "UMP-45", skinName = "Капрал", rarity = Rarity.MILSPEC, price = 45.0, assetPath = "skins/730-ump-45-corporal-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),

            // === ПРОМЫШЛЕННОЕ (UNCOMMON) ===
            SkinItem(id = "skin_tec9_sandstorm", weaponName = "TEC-9", skinName = "Песчаная буря", rarity = Rarity.UNCOMMON, price = 42.0, assetPath = "skins/tec9_sandstorm.webp", isStatTrak = false, wear = "После полевых испытаний"),
            SkinItem(id = "skin_tec9_terrace", weaponName = "TEC-9", skinName = "Терраса", rarity = Rarity.UNCOMMON, price = 39.0, assetPath = "skins/730-tec-9-terrace-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_p90_aeolian_light", weaponName = "P90", skinName = "Эолийский свет", rarity = Rarity.UNCOMMON, price = 36.0, assetPath = "skins/730-p90-aeolian-light-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_cz75_tigris", weaponName = "CZ75-Auto", skinName = "Тигр", rarity = Rarity.UNCOMMON, price = 34.0, assetPath = "skins/730-cz75-auto-tigris-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_dual_berettas_retribution", weaponName = "Dual Berettas", skinName = "Возмездие", rarity = Rarity.UNCOMMON, price = 32.0, assetPath = "skins/730-dual-berettas-retribution-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_dual_berettas_urban_shock", weaponName = "Dual Berettas", skinName = "Городской шок", rarity = Rarity.UNCOMMON, price = 30.0, assetPath = "skins/730-dual-berettas-urban-shock-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_pp_bizon_thermal", weaponName = "ПП-19 Бизон", skinName = "Термальные потоки", rarity = Rarity.UNCOMMON, price = 28.0, assetPath = "skins/730-pp-bizon-thermal-currents-factory-new.webp", isStatTrak = false, wear = "Прямо с завода"),
            SkinItem(id = "skin_mp7_sunbaked", weaponName = "MP7", skinName = "Выгоревший на солнце", rarity = Rarity.UNCOMMON, price = 26.0, assetPath = "skins/730-mp7-sunbaked-factory-new.webp", isStatTrak = true, wear = "Прямо с завода"),
            SkinItem(id = "skin_p250_contaminant", weaponName = "P250", skinName = "Загрязнитель", rarity = Rarity.UNCOMMON, price = 24.0, assetPath = "skins/730-p250-contaminant-factory-new.webp", isStatTrak = false, wear = "Прямо с завода")
        )
    }

    // Все кейсы строго отсортированы по возрастанию цены: от 29 ₽ до 1 500 000 ₽!
    val allCases: List<CaseItem> by lazy {
        val skins = allSkins
        listOf(
            CaseItem(id = "case_revolver", name = "КЕЙС «РЕВОЛЬВЕР»", category = "Серийные", price = 29.0, assetPath = "cases/730-revolver-case.webp", containedSkins = getSkinsForCase("Серийные", 0, skins)),
            CaseItem(id = "case_danger_zone", name = "ЗОНА ОПАСНОСТИ", category = "Серийные", price = 49.0, assetPath = "cases/730-danger-zone-case.webp", containedSkins = getSkinsForCase("Серийные", 1, skins)),
            CaseItem(id = "case_horizon", name = "ГОРИЗОНТ", category = "Серийные", price = 69.0, assetPath = "cases/730-horizon-case.webp", containedSkins = getSkinsForCase("Серийные", 2, skins)),
            CaseItem(id = "case_clutch", name = "РЕШАЮЩИЙ РАУНД (CLUTCH)", category = "Серийные", price = 89.0, assetPath = "cases/730-clutch-case.webp", containedSkins = getSkinsForCase("Серийные", 3, skins)),
            CaseItem(id = "case_prisma", name = "ПРИЗМА", category = "Серийные", price = 119.0, assetPath = "cases/730-prisma-case.webp", containedSkins = getSkinsForCase("Серийные", 4, skins)),
            CaseItem(id = "case_prisma_2", name = "ПРИЗМА 2", category = "Серийные", price = 149.0, assetPath = "cases/730-prisma-2-case.webp", containedSkins = getSkinsForCase("Серийные", 5, skins)),
            CaseItem(id = "case_fracture", name = "РАЗЛОМ (FRACTURE)", category = "Серийные", price = 189.0, assetPath = "cases/730-fracture-case.webp", containedSkins = getSkinsForCase("Серийные", 6, skins)),
            CaseItem(id = "case_snakebite", name = "ЗМЕИНЫЙ УКУС", category = "Серийные", price = 239.0, assetPath = "cases/730-snakebite-case.webp", containedSkins = getSkinsForCase("Серийные", 7, skins)),
            CaseItem(id = "case_dreams_nightmares", name = "ГРЁЗЫ И КОШМАРЫ", category = "Серийные", price = 299.0, assetPath = "cases/730-dreams-nightmares-case.webp", containedSkins = getSkinsForCase("Серийные", 8, skins)),
            CaseItem(id = "case_revolution", name = "РЕВОЛЮЦИЯ", category = "Серийные", price = 369.0, assetPath = "cases/730-revolution-case.webp", containedSkins = getSkinsForCase("Серийные", 9, skins)),
            CaseItem(id = "case_falchion", name = "ФАЛЬШИОН", category = "Серийные", price = 449.0, assetPath = "cases/730-falchion-case.webp", containedSkins = getSkinsForCase("Серийные", 10, skins)),
            CaseItem(id = "case_chroma", name = "ХРОМА", category = "Серийные", price = 549.0, assetPath = "cases/730-chroma-case.webp", containedSkins = getSkinsForCase("Серийные", 11, skins)),
            CaseItem(id = "case_chroma_2", name = "ХРОМА 2", category = "Серийные", price = 679.0, assetPath = "cases/730-chroma-2-case.webp", containedSkins = getSkinsForCase("Серийные", 12, skins)),
            CaseItem(id = "case_chroma_3", name = "ХРОМА 3", category = "Серийные", price = 799.0, assetPath = "cases/730-chroma-3-case.webp", containedSkins = getSkinsForCase("Серийные", 13, skins)),
            CaseItem(id = "case_gamma", name = "ГАММА", category = "Серийные", price = 949.0, assetPath = "cases/730-gamma-case.webp", containedSkins = getSkinsForCase("Серийные", 14, skins)),
            CaseItem(id = "case_gamma_2", name = "ГАММА 2", category = "Серийные", price = 1190.0, assetPath = "cases/730-gamma-2-case.webp", containedSkins = getSkinsForCase("Серийные", 15, skins)),
            CaseItem(id = "case_spectrum", name = "СПЕКТР", category = "Серийные", price = 1390.0, assetPath = "cases/730-spectrum-case.webp", containedSkins = getSkinsForCase("Серийные", 16, skins)),
            CaseItem(id = "case_spectrum_2", name = "СПЕКТР 2", category = "Серийные", price = 1690.0, assetPath = "cases/730-spectrum-2-case.webp", containedSkins = getSkinsForCase("Серийные", 17, skins)),
            CaseItem(id = "case_cs20", name = "CS20 КЕЙС", category = "Именные", price = 1990.0, assetPath = "cases/730-cs20-case.webp", containedSkins = getSkinsForCase("Именные", 0, skins)),
            CaseItem(id = "case_huntsman", name = "ОХОТНИЧИЙ КЕЙС", category = "Именные", price = 2490.0, assetPath = "cases/730-huntsman-weapon-case.webp", containedSkins = getSkinsForCase("Именные", 1, skins)),
            CaseItem(id = "case_phoenix", name = "ОПЕРАЦИЯ ФЕНИКС", category = "Лимитированные", price = 2990.0, assetPath = "cases/730-operation-phoenix-weapon-case.webp", containedSkins = getSkinsForCase("Лимитированные", 0, skins)),
            CaseItem(id = "case_breakout", name = "ОПЕРАЦИЯ ПРОРЫВ", category = "Лимитированные", price = 3790.0, assetPath = "cases/730-operation-breakout-weapon-case.webp", containedSkins = getSkinsForCase("Лимитированные", 1, skins)),
            CaseItem(id = "case_wildfire", name = "ДИКОЕ ПЛАМЯ", category = "Лимитированные", price = 4890.0, assetPath = "cases/730-operation-wildfire-case.webp", containedSkins = getSkinsForCase("Лимитированные", 2, skins)),
            CaseItem(id = "case_broken_fang", name = "СЛОМАННЫЙ КЛЫК", category = "Лимитированные", price = 6490.0, assetPath = "cases/730-operation-broken-fang-case.webp", containedSkins = getSkinsForCase("Лимитированные", 3, skins)),
            CaseItem(id = "case_riptide", name = "ХИЩНЫЕ ВОДЫ (RIPTIDE)", category = "Лимитированные", price = 8490.0, assetPath = "cases/730-operation-riptide-case.webp", containedSkins = getSkinsForCase("Лимитированные", 4, skins)),
            CaseItem(id = "case_hydra", name = "ОПЕРАЦИЯ ГИДРА", category = "Лимитированные", price = 12490.0, assetPath = "cases/730-operation-hydra-case.webp", containedSkins = getSkinsForCase("Лимитированные", 5, skins)),
            CaseItem(id = "case_csgo_weapon", name = "ОРУЖЕЙНЫЙ КЕЙС CS:GO #1", category = "Именные", price = 17900.0, assetPath = "cases/730-cs-go-weapon-case.webp", containedSkins = getSkinsForCase("Именные", 2, skins)),
            CaseItem(id = "case_esports_2013", name = "ESPORTS 2013 WINTER", category = "Лимитированные", price = 24900.0, assetPath = "cases/730-esports-2013-winter-case.webp", containedSkins = getSkinsForCase("Лимитированные", 6, skins)),
            CaseItem(id = "case_bravo", name = "ОПЕРАЦИЯ БРАВО", category = "Лимитированные", price = 34900.0, assetPath = "cases/730-operation-bravo-case.webp", containedSkins = getSkinsForCase("Лимитированные", 7, skins)),
            CaseItem(id = "case_anubis", name = "СУВЕНИРНЫЙ АНУБИС 2024", category = "Лимитированные", price = 49900.0, assetPath = "cases/730-anubis-collection-package.webp", containedSkins = getSkinsForCase("Лимитированные", 8, skins)),
            CaseItem(id = "case_cobblestone", name = "COBBLESTONE SOUVENIR", category = "Лимитированные", price = 89000.0, assetPath = "cases/730-esl-one-cologne-2014-cobblestone-souvenir-package.webp", containedSkins = getSkinsForCase("Лимитированные", 9, skins)),
            CaseItem(id = "case_knife_elite", name = "★ НОЖЕВОЙ ДЖЕКПОТ ★", category = "Ножевые", price = 190000.0, assetPath = "cases/case_23.webp", containedSkins = getSkinsForCase("Ножевые", 0, skins)),
            CaseItem(id = "case_souvenir_dragon", name = "★ COBBLESTONE ДРАКОН ★", category = "Лимитированные", price = 590000.0, assetPath = "cases/730-atlanta-2017-cobblestone-souvenir-package.webp", containedSkins = getSkinsForCase("Лимитированные", 10, skins)),
            CaseItem(id = "case_oligarh_9m", name = "★ КЕЙС ОЛИГАРХА 9,000,000 ₽ ★", category = "Олигарх", price = 1500000.0, assetPath = "cases/730-cologne-2016-cobblestone-souvenir-package.webp", containedSkins = getSkinsForCase("Олигарх", 0, skins))
        )
    }

    private fun getSkinsForCase(category: String, index: Int, all: List<SkinItem>): List<SkinItem> {
        return when (category) {
            "Олигарх" -> {
                all.filter { it.price >= 4000000.0 }
            }
            "Ножевые" -> {
                val knives = all.filter { it.rarity == Rarity.SPECIAL }
                val start = (index * 4) % (knives.size.coerceAtLeast(1))
                knives.drop(start).take(10).ifEmpty { knives.take(10) }
            }
            "Лимитированные" -> {
                val specials = all.filter { it.rarity == Rarity.SPECIAL }.drop(index % 15).take(3)
                val coverts = all.filter { it.rarity == Rarity.COVERT }.drop(index % 15).take(4)
                val classifieds = all.filter { it.rarity == Rarity.CLASSIFIED }.drop(index % 12).take(3)
                (specials + coverts + classifieds).distinctBy { it.id }
            }
            else -> {
                val specials = all.filter { it.rarity == Rarity.SPECIAL }.drop(index % 15).take(1)
                val coverts = all.filter { it.rarity == Rarity.COVERT }.drop(index % 15).take(2)
                val classifieds = all.filter { it.rarity == Rarity.CLASSIFIED }.drop(index % 15).take(3)
                val restricted = all.filter { it.rarity == Rarity.RESTRICTED }.drop(index % 15).take(4)
                val milspec = all.filter { it.rarity == Rarity.MILSPEC || it.rarity == Rarity.UNCOMMON }.drop(index % 15).take(4)
                (specials + coverts + classifieds + restricted + milspec).distinctBy { it.id }
            }
        }
    }

    val avatarAssets: List<String> by lazy {
        listOf(
            "avatars/0041b9003317b9a798e6c8169f8d5decd81b1cf5_full-extractpics.jpg",
            "avatars/0b3c26b3d40ae0b54b5732c4118915e69ca24dd1_full-extractpics.jpg",
            "avatars/0e7b2d1bc9c480d3ff541ba81aa7a7e9ae76d650_full-extractpics.jpg",
            "avatars/1410806235332dbb2e417b5ae8a64f938e4be576_full-extractpics.jpg",
            "avatars/194f11f1c8530aa1e3a36f6c1b9da49dc253619e_full-extractpics.jpg",
            "avatars/211d5b1d960d906e064b00a2decdb2765b381f20_full-extractpics.jpg",
            "avatars/247227ca2f8e6bd6a9bab13d695076d21a88ed16_full-extractpics.jpg",
            "avatars/299539c66179b18233b3b6c4c49316d33695f7a5_full-extractpics.jpg",
            "avatars/302993734630f2e48c7bda3fcb605202c735a6ec_full-extractpics.jpg",
            "avatars/48e89a15984038080978db3134bd3f888eff2a2b_full-extractpics.jpg",
            "avatars/4aa61e62fe8401da824bc7d538e236ca01e777b5_full-extractpics.jpg",
            "avatars/51fbe5d1ae932f2095bde90337724bd658836eb9_full-extractpics.jpg",
            "avatars/52de2ca608847f25071d112ac20a6718ff4b3a89_full-extractpics.jpg",
            "avatars/53d8390d550800e26bae00f81c08ed229ed5d632_full-extractpics.jpg",
            "avatars/5853401fab5456a5095e2fb65759df14f0941dcb_full-extractpics.jpg",
            "avatars/5c4acdb2f63c7d98b9dd02bce37780af802cfa63_full-extractpics.jpg",
            "avatars/6540d7449e08069f6da962284bd294a942d3006c_full-extractpics.jpg",
            "avatars/656ded7d952f996afc164f0dc1fed007221377c9_full-extractpics.jpg",
            "avatars/6c32d5f38e48adbe8793e93f046dbc09b30c7e53_full-extractpics.jpg",
            "avatars/6e7b606931ceda801b5a7d202559e2dafbc421db_full-extractpics.jpg",
            "avatars/a0ce559006a690e56b8b02baecb967aa76a2c6f6_full-extractpics.jpg",
            "avatars/a4e3d08f51170a9212338bc3263888fdaec1b851_full-extractpics.jpg",
            "avatars/b98cfa4eb3a17cf046043c290e17de898c8cf7a2_full-extractpics.jpg",
            "avatars/c061f84ee09f146ef15a5dc1f6d11a767c49f09e_full-extractpics.jpg",
            "avatars/c1424e3d53dcecbdf960fb0eeb8d7109b07e704e_full-extractpics.jpg",
            "avatars/crispprocessed1c9d8185-f21f-40_fs5ww-extractpics.jpg",
            "avatars/e123051ffc4f07e73737d58c17e3bee71366fc34_full-extractpics.jpg",
            "avatars/e37e2959c3aa03cc48e1d8e24becf4b3ec3eaa62_full-extractpics.jpg",
            "avatars/f63cbcb22953d8aaae0b354303357e3382540e5a_full-extractpics.jpg",
            "avatars/photo2026-09-3019-31-36_70il2z-extractpics.jpg"
        )
    }
}
