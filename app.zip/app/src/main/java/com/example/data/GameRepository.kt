package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.audio.SoundEffects
import com.example.model.AppSettings
import com.example.model.BattleDifficulty
import com.example.model.BattleMode
import com.example.model.BattleRoundResult
import com.example.model.CaseItem
import com.example.model.FarmUpgrade
import com.example.model.LiveDrop
import com.example.model.PlayerAccount
import com.example.model.PlayerProfile
import com.example.model.Rarity
import com.example.model.SkinItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.random.Random

class GameRepository(
    private val context: Context,
    val soundEffects: SoundEffects
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("case_battle_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Default)

    // Account system
    private val _accounts = MutableStateFlow<List<PlayerAccount>>(emptyList())
    val accounts: StateFlow<List<PlayerAccount>> = _accounts.asStateFlow()

    private val _activeAccountId = MutableStateFlow<String>("")
    val activeAccountId: StateFlow<String> = _activeAccountId.asStateFlow()

    // Active Profile & Inventory
    private val _profile = MutableStateFlow(PlayerProfile())
    val profile: StateFlow<PlayerProfile> = _profile.asStateFlow()

    private val _inventory = MutableStateFlow<List<SkinItem>>(emptyList())
    val inventory: StateFlow<List<SkinItem>> = _inventory.asStateFlow()

    // Settings (including Offline mode)
    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    // Live feed
    private val _liveDrops = MutableStateFlow<List<LiveDrop>>(emptyList())
    val liveDrops: StateFlow<List<LiveDrop>> = _liveDrops.asStateFlow()

    private val _farmUpgrades = MutableStateFlow<List<FarmUpgrade>>(defaultFarmUpgrades())
    val farmUpgrades: StateFlow<List<FarmUpgrade>> = _farmUpgrades.asStateFlow()

    init {
        loadData()
        startLiveDropTicker()
        startPassiveFarmTicker()
    }

    private fun defaultFarmUpgrades(): List<FarmUpgrade> {
        return listOf(
            FarmUpgrade("click_1", "Клик-молот", "+2 ₽ за каждый тап по контейнеру", 100.0, 2.0, 0.0),
            FarmUpgrade("click_2", "Перчатки с шипами", "+5 ₽ за тап и шанс на критический клик", 350.0, 5.0, 0.0),
            FarmUpgrade("passive_1", "Сборщик металлолома", "+3 ₽/сек в фоновом режиме", 200.0, 0.0, 3.0),
            FarmUpgrade("passive_2", "Мусоровоз 2.0", "+12 ₽/сек авто-дохода", 900.0, 0.0, 12.0),
            FarmUpgrade("passive_3", "Крипто-ферма скинов", "+45 ₽/сек авто-дохода", 3500.0, 0.0, 45.0),
            FarmUpgrade("passive_4", "Менеджер биржи", "+150 ₽/сек пассивного дохода", 12000.0, 0.0, 150.0)
        )
    }

    // --- Account Management ---

    fun createAccount(
        name: String,
        avatarAsset: String = GameCatalog.avatarAssets.random(),
        initialBalance: Double = 5000.0
    ): PlayerAccount {
        // Starter inventory for new account
        val starters = GameCatalog.allSkins.filter {
            it.rarity == Rarity.MILSPEC || it.rarity == Rarity.RESTRICTED
        }.shuffled().take(4).map { it.copy(instanceId = UUID.randomUUID().toString()) }

        val newAcc = PlayerAccount(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "Игрок_${Random.nextInt(100, 999)}" },
            avatarAsset = avatarAsset,
            balance = initialBalance,
            inventory = starters
        )

        val updated = _accounts.value + newAcc
        _accounts.value = updated
        switchAccount(newAcc.id)
        saveData()
        return newAcc
    }

    fun switchAccount(accountId: String) {
        // Save current active account's state before switching
        val currentId = _activeAccountId.value
        val currentAcc = _accounts.value.find { it.id == currentId }
        if (currentAcc != null) {
            val savedAcc = currentAcc.copy(
                name = _profile.value.name,
                avatarAsset = _profile.value.avatarAsset,
                balance = _profile.value.balance,
                casesOpened = _profile.value.casesOpened,
                upgradesTotal = _profile.value.upgradesTotal,
                upgradesWon = _profile.value.upgradesWon,
                battlesWon = _profile.value.battlesWon,
                contractsCompleted = _profile.value.contractsCompleted,
                bestDrop = _profile.value.bestDrop,
                clickPower = _profile.value.clickPower,
                passiveIncomePerSec = _profile.value.passiveIncomePerSec,
                clickerCoinsTotal = _profile.value.clickerCoinsTotal,
                inventory = _inventory.value
            )
            _accounts.update { list -> list.map { if (it.id == currentId) savedAcc else it } }
        }

        val target = _accounts.value.find { it.id == accountId } ?: return
        _activeAccountId.value = target.id
        _profile.value = PlayerProfile(
            accountId = target.id,
            name = target.name,
            avatarAsset = target.avatarAsset,
            balance = target.balance,
            casesOpened = target.casesOpened,
            upgradesTotal = target.upgradesTotal,
            upgradesWon = target.upgradesWon,
            battlesWon = target.battlesWon,
            contractsCompleted = target.contractsCompleted,
            bestDrop = target.bestDrop,
            clickPower = target.clickPower,
            passiveIncomePerSec = target.passiveIncomePerSec,
            clickerCoinsTotal = target.clickerCoinsTotal,
            rankTitle = target.rankTitle
        )
        _inventory.value = target.inventory
        saveData()
    }

    fun deleteAccount(accountId: String): Boolean {
        if (_accounts.value.size <= 1) return false // Prevent deleting last remaining account
        _accounts.update { list -> list.filterNot { it.id == accountId } }
        if (_activeAccountId.value == accountId) {
            val next = _accounts.value.first()
            switchAccount(next.id)
        }
        saveData()
        return true
    }

    // --- Settings & Offline Mode ---

    fun setOfflineMode(enabled: Boolean) {
        _settings.update { it.copy(isOfflineMode = enabled) }
        saveData()
    }

    fun setFastRollDefault(enabled: Boolean) {
        _settings.update { it.copy(isFastRollDefault = enabled) }
        saveData()
    }

    // --- Game Logic ---

    fun openCase(caseItem: CaseItem, count: Int = 1): List<SkinItem> {
        val totalCost = caseItem.price * count
        if (_profile.value.balance < totalCost) {
            return emptyList()
        }

        // Deduct cost
        _profile.update { it.copy(balance = it.balance - totalCost) }

        val wonSkins = mutableListOf<SkinItem>()
        for (i in 0 until count) {
            val won = rollSkinFromCase(caseItem)
            val instance = won.copy(instanceId = UUID.randomUUID().toString())
            wonSkins.add(instance)

            // Publish to live drops if not in strict offline mode or locally
            val drop = LiveDrop(
                userName = _profile.value.name,
                avatarAsset = _profile.value.avatarAsset,
                skin = instance,
                caseName = caseItem.name
            )
            _liveDrops.update { listOf(drop) + it.take(25) }
        }

        // Add to inventory
        _inventory.update { wonSkins + it }

        // Update profile stats
        val best = _profile.value.bestDrop
        val newBest = (wonSkins + listOfNotNull(best)).maxByOrNull { it.price }

        _profile.update {
            it.copy(
                casesOpened = it.casesOpened + count,
                bestDrop = newBest
            )
        }

        syncCurrentAccount()
        saveData()
        return wonSkins
    }

    fun rollSkinFromCase(caseItem: CaseItem): SkinItem {
        val skins = caseItem.containedSkins
        if (skins.isEmpty()) return GameCatalog.allSkins.random()

        val weights = skins.map { skin ->
            val w = when (skin.rarity) {
                Rarity.COMMON -> 600
                Rarity.UNCOMMON -> 300
                Rarity.MILSPEC -> 150
                Rarity.RESTRICTED -> 60
                Rarity.CLASSIFIED -> 20
                Rarity.COVERT -> 7
                Rarity.SPECIAL -> 2
            }
            skin to w
        }

        val totalWeight = weights.sumOf { it.second }
        var roll = Random.nextInt(totalWeight)
        for ((skin, weight) in weights) {
            roll -= weight
            if (roll < 0) {
                return skin
            }
        }
        return skins.random()
    }

    fun sellSkin(instanceId: String): Double {
        val item = _inventory.value.find { it.instanceId == instanceId } ?: return 0.0
        _inventory.update { it.filterNot { s -> s.instanceId == instanceId } }
        _profile.update { it.copy(balance = it.balance + item.price) }
        syncCurrentAccount()
        saveData()
        return item.price
    }

    fun sellAllByRarity(vararg rarities: Rarity): Double {
        val targetRarities = rarities.toSet()
        val itemsToSell = _inventory.value.filter { it.rarity in targetRarities }
        val sum = itemsToSell.sumOf { it.price }
        _inventory.update { it.filterNot { s -> s.rarity in targetRarities } }
        _profile.update { it.copy(balance = it.balance + sum) }
        syncCurrentAccount()
        saveData()
        return sum
    }

    fun executeUpgrade(
        inputInstanceIds: List<String>,
        targetSkin: SkinItem,
        addedCash: Double
    ): UpgradeResult {
        val inputItems = _inventory.value.filter { it.instanceId in inputInstanceIds }
        val totalInputValue = inputItems.sumOf { it.price } + addedCash

        if (totalInputValue <= 0.0) {
            return UpgradeResult(success = false, odds = 0.0, roll = 1.0, wonSkin = null, cashback = 0.0)
        }

        if (addedCash > 0) {
            if (_profile.value.balance < addedCash) {
                return UpgradeResult(success = false, odds = 0.0, roll = 1.0, wonSkin = null, cashback = 0.0)
            }
            _profile.update { it.copy(balance = it.balance - addedCash) }
        }

        _inventory.update { it.filterNot { s -> s.instanceId in inputInstanceIds } }

        val rawOdds = (totalInputValue / targetSkin.price) * 0.98
        val odds = rawOdds.coerceIn(0.01, 0.85)
        val roll = Random.nextDouble(0.0, 1.0)
        val success = roll <= odds

        val cashback = if (!success) (totalInputValue * 0.10).coerceAtLeast(1.0) else 0.0

        if (success) {
            val awardedSkin = targetSkin.copy(instanceId = UUID.randomUUID().toString())
            _inventory.update { listOf(awardedSkin) + it }
            _profile.update {
                it.copy(
                    upgradesTotal = it.upgradesTotal + 1,
                    upgradesWon = it.upgradesWon + 1
                )
            }
            _liveDrops.update {
                listOf(
                    LiveDrop(
                        userName = _profile.value.name,
                        avatarAsset = _profile.value.avatarAsset,
                        skin = awardedSkin,
                        caseName = "Апгрейд 2.0"
                    )
                ) + it.take(25)
            }
            syncCurrentAccount()
            saveData()
            return UpgradeResult(success = true, odds = odds, roll = roll, wonSkin = awardedSkin, cashback = 0.0)
        } else {
            _profile.update {
                it.copy(
                    balance = it.balance + cashback,
                    upgradesTotal = it.upgradesTotal + 1
                )
            }
            syncCurrentAccount()
            saveData()
            return UpgradeResult(success = false, odds = odds, roll = roll, wonSkin = null, cashback = cashback)
        }
    }

    data class UpgradeResult(
        val success: Boolean,
        val odds: Double,
        val roll: Double,
        val wonSkin: SkinItem?,
        val cashback: Double
    )

    fun executeContract(inputInstanceIds: List<String>): SkinItem? {
        if (inputInstanceIds.size !in 3..10) return null
        val items = _inventory.value.filter { it.instanceId in inputInstanceIds }
        if (items.size != inputInstanceIds.size) return null

        _inventory.update { it.filterNot { s -> s.instanceId in inputInstanceIds } }

        val maxRarityOrdinal = items.maxOf { it.rarity.ordinal }
        val targetRarityOrdinal = (maxRarityOrdinal + 1).coerceAtMost(Rarity.SPECIAL.ordinal)
        val targetRarity = Rarity.entries[targetRarityOrdinal]

        val pool = GameCatalog.allSkins.filter { it.rarity == targetRarity }
        val won = (if (pool.isNotEmpty()) pool.random() else GameCatalog.allSkins.random())
            .copy(instanceId = UUID.randomUUID().toString())

        _inventory.update { listOf(won) + it }
        _profile.update { it.copy(contractsCompleted = it.contractsCompleted + 1) }

        _liveDrops.update {
            listOf(
                LiveDrop(
                    userName = _profile.value.name,
                    avatarAsset = _profile.value.avatarAsset,
                    skin = won,
                    caseName = "Контракт обмена"
                )
            ) + it.take(25)
        }
        syncCurrentAccount()
        saveData()
        return won
    }

    fun clickFarm(): Double {
        val earned = _profile.value.clickPower
        _profile.update {
            it.copy(
                balance = it.balance + earned,
                clickerCoinsTotal = it.clickerCoinsTotal + earned
            )
        }
        syncCurrentAccount()
        return earned
    }

    fun buyFarmUpgrade(upgradeId: String): Boolean {
        val current = _farmUpgrades.value.find { it.id == upgradeId } ?: return false
        val cost = current.cost * (1.0 + current.level * 0.45)
        if (_profile.value.balance < cost) return false

        _profile.update {
            it.copy(
                balance = it.balance - cost,
                clickPower = it.clickPower + current.clickBonus,
                passiveIncomePerSec = it.passiveIncomePerSec + current.passiveBonus
            )
        }

        _farmUpgrades.update { list ->
            list.map {
                if (it.id == upgradeId) it.copy(level = it.level + 1) else it
            }
        }
        syncCurrentAccount()
        saveData()
        return true
    }

    fun addBonusCoins(amount: Double) {
        _profile.update { it.copy(balance = it.balance + amount) }
        syncCurrentAccount()
        saveData()
    }

    fun updateProfileName(name: String) {
        _profile.update { it.copy(name = name) }
        syncCurrentAccount()
        saveData()
    }

    fun updateAvatar(asset: String) {
        _profile.update { it.copy(avatarAsset = asset) }
        syncCurrentAccount()
        saveData()
    }

    fun finishCaseBattle(won: Boolean, wonSkins: List<SkinItem>) {
        if (won) {
            _inventory.update { wonSkins + it }
            _profile.update { it.copy(battlesWon = it.battlesWon + 1) }
        }
        syncCurrentAccount()
        saveData()
    }

    private fun syncCurrentAccount() {
        val currentId = _activeAccountId.value
        _accounts.update { list ->
            list.map { acc ->
                if (acc.id == currentId) {
                    acc.copy(
                        name = _profile.value.name,
                        avatarAsset = _profile.value.avatarAsset,
                        balance = _profile.value.balance,
                        casesOpened = _profile.value.casesOpened,
                        upgradesTotal = _profile.value.upgradesTotal,
                        upgradesWon = _profile.value.upgradesWon,
                        battlesWon = _profile.value.battlesWon,
                        contractsCompleted = _profile.value.contractsCompleted,
                        bestDrop = _profile.value.bestDrop,
                        clickPower = _profile.value.clickPower,
                        passiveIncomePerSec = _profile.value.passiveIncomePerSec,
                        clickerCoinsTotal = _profile.value.clickerCoinsTotal,
                        inventory = _inventory.value
                    )
                } else acc
            }
        }
    }

    private fun startPassiveFarmTicker() {
        scope.launch {
            while (isActive) {
                delay(1000)
                val passive = _profile.value.passiveIncomePerSec
                if (passive > 0.0) {
                    _profile.update {
                        it.copy(
                            balance = it.balance + passive,
                            clickerCoinsTotal = it.clickerCoinsTotal + passive
                        )
                    }
                }
            }
        }
    }

    private fun startLiveDropTicker() {
        val mockUsers = listOf(
            "s1mple_king", "b1t_pro", "monesy666", "electroNic", "niko_deagle",
            "donk_destroyer", "cs_sniper", "navi_fan", "vitality_ace", "cloud9_pro",
            "кекс_мастер", "агент_ава", "русский_мясник", "папич_ролл", "барон_мусора"
        )

        scope.launch {
            while (isActive) {
                delay(Random.nextLong(2500, 5000))
                // Only generate network live drops when NOT in offline mode!
                if (!_settings.value.isOfflineMode) {
                    val randomCase = GameCatalog.allCases.random()
                    val randomSkin = randomCase.containedSkins.random()
                    val randomUser = mockUsers.random()
                    val randomAvatar = GameCatalog.avatarAssets.random()

                    val drop = LiveDrop(
                        userName = randomUser,
                        avatarAsset = randomAvatar,
                        skin = randomSkin,
                        caseName = randomCase.name
                    )
                    _liveDrops.update { listOf(drop) + it.take(25) }
                }
            }
        }
    }

    private fun saveData() {
        scope.launch {
            try {
                // Save settings
                val s = _settings.value
                prefs.edit().apply {
                    putBoolean("isOfflineMode", s.isOfflineMode)
                    putBoolean("isSoundEnabled", s.isSoundEnabled)
                    putBoolean("isHapticsEnabled", s.isHapticsEnabled)
                    putBoolean("isFastRollDefault", s.isFastRollDefault)
                    putString("activeAccountId", _activeAccountId.value)

                    // Serialize accounts
                    val accsArray = JSONArray()
                    for (acc in _accounts.value) {
                        val accObj = JSONObject().apply {
                            put("id", acc.id)
                            put("name", acc.name)
                            put("avatarAsset", acc.avatarAsset)
                            put("balance", acc.balance)
                            put("casesOpened", acc.casesOpened)
                            put("upgradesTotal", acc.upgradesTotal)
                            put("upgradesWon", acc.upgradesWon)
                            put("battlesWon", acc.battlesWon)
                            put("contractsCompleted", acc.contractsCompleted)
                            put("clickPower", acc.clickPower)
                            put("passiveIncomePerSec", acc.passiveIncomePerSec)
                            put("clickerCoinsTotal", acc.clickerCoinsTotal)
                            put("rankTitle", acc.rankTitle)

                            val invArr = JSONArray()
                            for (item in acc.inventory) {
                                invArr.put(JSONObject().apply {
                                    put("id", item.id)
                                    put("instanceId", item.instanceId)
                                    put("weaponName", item.weaponName)
                                    put("skinName", item.skinName)
                                    put("rarity", item.rarity.name)
                                    put("price", item.price)
                                    put("assetPath", item.assetPath)
                                    put("isStatTrak", item.isStatTrak)
                                    put("wear", item.wear)
                                })
                            }
                            put("inventory", invArr)
                        }
                        accsArray.put(accObj)
                    }
                    putString("accounts_json", accsArray.toString())
                    apply()
                }
            } catch (_: Exception) {}
        }
    }

    private fun loadData() {
        try {
            val isOffline = prefs.getBoolean("isOfflineMode", false)
            val isSound = prefs.getBoolean("isSoundEnabled", true)
            val isHaptics = prefs.getBoolean("isHapticsEnabled", true)
            val isFast = prefs.getBoolean("isFastRollDefault", false)
            _settings.value = AppSettings(
                isOfflineMode = isOffline,
                isSoundEnabled = isSound,
                isHapticsEnabled = isHaptics,
                isFastRollDefault = isFast
            )
            soundEffects.setSoundEnabled(isSound)
            soundEffects.setHapticsEnabled(isHaptics)

            val accsJson = prefs.getString("accounts_json", null)
            val loadedAccounts = mutableListOf<PlayerAccount>()

            if (!accsJson.isNullOrEmpty()) {
                val array = JSONArray(accsJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val invArr = obj.optJSONArray("inventory") ?: JSONArray()
                    val invList = mutableListOf<SkinItem>()
                    for (j in 0 until invArr.length()) {
                        val itemObj = invArr.getJSONObject(j)
                        val itemId = itemObj.getString("id")
                        val catalogSkin = GameCatalog.allSkins.find { it.id == itemId }
                        val rawAsset = itemObj.getString("assetPath")
                        val finalAsset = if (rawAsset.contains("skin_137_") || !rawAsset.startsWith("skins/")) {
                            catalogSkin?.assetPath ?: GameCatalog.allSkins.random().assetPath
                        } else {
                            rawAsset
                        }
                        val finalWeapon = catalogSkin?.weaponName ?: itemObj.getString("weaponName")
                        val finalSkinName = catalogSkin?.skinName ?: itemObj.getString("skinName")
                        val finalRarity = catalogSkin?.rarity ?: Rarity.valueOf(itemObj.getString("rarity"))

                        invList.add(
                            SkinItem(
                                id = itemId,
                                instanceId = itemObj.getString("instanceId"),
                                weaponName = finalWeapon,
                                skinName = finalSkinName,
                                rarity = finalRarity,
                                price = itemObj.getDouble("price"),
                                assetPath = finalAsset,
                                isStatTrak = itemObj.optBoolean("isStatTrak", false),
                                wear = itemObj.optString("wear", "Прямо с завода")
                            )
                        )
                    }

                    loadedAccounts.add(
                        PlayerAccount(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            avatarAsset = obj.optString("avatarAsset", GameCatalog.avatarAssets.first()),
                            balance = obj.getDouble("balance"),
                            casesOpened = obj.optInt("casesOpened", 0),
                            upgradesTotal = obj.optInt("upgradesTotal", 0),
                            upgradesWon = obj.optInt("upgradesWon", 0),
                            battlesWon = obj.optInt("battlesWon", 0),
                            contractsCompleted = obj.optInt("contractsCompleted", 0),
                            clickPower = obj.optDouble("clickPower", 1.0),
                            passiveIncomePerSec = obj.optDouble("passiveIncomePerSec", 0.0),
                            clickerCoinsTotal = obj.optDouble("clickerCoinsTotal", 0.0),
                            rankTitle = obj.optString("rankTitle", "Новичок Батлов"),
                            inventory = invList
                        )
                    )
                }
            }

            if (loadedAccounts.isEmpty()) {
                val defaultStarters = GameCatalog.allSkins.filter {
                    it.rarity == Rarity.MILSPEC || it.rarity == Rarity.RESTRICTED
                }.shuffled().take(4).map { it.copy(instanceId = UUID.randomUUID().toString()) }

                val defaultAcc = PlayerAccount(
                    id = UUID.randomUUID().toString(),
                    name = "Воробей",
                    avatarAsset = GameCatalog.avatarAssets.firstOrNull()
                        ?: "avatars/0041b9003317b9a798e6c8169f8d5decd81b1cf5_full-extractpics.jpg",
                    balance = 5000.0,
                    inventory = defaultStarters
                )
                loadedAccounts.add(defaultAcc)
            }

            _accounts.value = loadedAccounts

            val savedActiveId = prefs.getString("activeAccountId", null)
            val initialActive = loadedAccounts.find { it.id == savedActiveId } ?: loadedAccounts.first()

            _activeAccountId.value = initialActive.id
            _profile.value = PlayerProfile(
                accountId = initialActive.id,
                name = initialActive.name,
                avatarAsset = initialActive.avatarAsset,
                balance = initialActive.balance,
                casesOpened = initialActive.casesOpened,
                upgradesTotal = initialActive.upgradesTotal,
                upgradesWon = initialActive.upgradesWon,
                battlesWon = initialActive.battlesWon,
                contractsCompleted = initialActive.contractsCompleted,
                bestDrop = initialActive.bestDrop,
                clickPower = initialActive.clickPower,
                passiveIncomePerSec = initialActive.passiveIncomePerSec,
                clickerCoinsTotal = initialActive.clickerCoinsTotal,
                rankTitle = initialActive.rankTitle
            )
            _inventory.value = initialActive.inventory
        } catch (_: Exception) {}
    }
}
