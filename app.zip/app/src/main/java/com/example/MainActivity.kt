package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import coil.Coil
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.audio.SoundEffects
import com.example.data.GameRepository
import com.example.ui.screens.MainGameScreen
import com.example.ui.theme.BgDark
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // High-performance Coil image loader optimized for mobile devices without stutter
        val imageLoader = ImageLoader.Builder(applicationContext)
            .memoryCache {
                MemoryCache.Builder(applicationContext)
                    .maxSizePercent(0.30) // 30% of app memory for cached weapon images
                    .strongReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(applicationContext.cacheDir.resolve("image_cache"))
                    .maxSizeBytes(128L * 1024L * 1024L) // 128 MB disk cache
                    .build()
            }
            .crossfade(false) // Disable alpha crossfade animation for instantaneous 60fps renders
            .respectCacheHeaders(false)
            .build()

        Coil.setImageLoader(imageLoader)

        val soundEffects = SoundEffects(applicationContext)
        val repository = GameRepository(applicationContext, soundEffects)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BgDark
                ) {
                    MainGameScreen(
                        repository = repository,
                        soundEffects = soundEffects
                    )
                }
            }
        }
    }
}
