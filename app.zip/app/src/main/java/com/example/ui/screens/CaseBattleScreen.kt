package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.audio.SoundEffects
import com.example.data.GameCatalog
import com.example.data.GameRepository
import com.example.model.BattleDifficulty
import com.example.model.BattleMode
import com.example.model.CaseItem
import com.example.model.SkinItem
import com.example.ui.components.SkinCard
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.FlameGold
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StrokeGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

@Composable
fun CaseBattleScreen(
    repository: GameRepository,
    soundEffects: SoundEffects,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile by repository.profile.collectAsState()

    var selectedCase by remember { mutableStateOf(GameCatalog.allCases.first()) }
    var battleRounds by remember { mutableIntStateOf(3) }
    var selectedMode by remember { mutableStateOf(BattleMode.STANDARD) }
    var selectedDifficulty by remember { mutableStateOf(BattleDifficulty.EASY) }

    var isBattling by remember { mutableStateOf(false) }
    var currentRound by remember { mutableIntStateOf(0) }

    val playerDrops = remember { mutableStateListOf<SkinItem>() }
    val botDrops = remember { mutableStateListOf<SkinItem>() }

    var battleWinner by remember { mutableStateOf<String?>(null) }
    var showWinnerDialog by remember { mutableStateOf(false) }

    // Dual reel spinning animation offsets
    val playerReelOffset = remember { Animatable(0f) }
    val botReelOffset = remember { Animatable(0f) }

    val playerReelList = remember { mutableStateListOf<SkinItem>() }
    val botReelList = remember { mutableStateListOf<SkinItem>() }

    val totalCost = selectedCase.price * battleRounds

    fun startBattle() {
        if (profile.balance < totalCost || isBattling) return

        repository.addBonusCoins(-totalCost)
        playerDrops.clear()
        botDrops.clear()
        isBattling = true
        currentRound = 0
        battleWinner = null

        scope.launch {
            for (round in 1..battleRounds) {
                currentRound = round

                // Generate win for this round
                val playerWonSkin = repository.rollSkinFromCase(selectedCase).copy(instanceId = UUID.randomUUID().toString())
                val botWonSkin = repository.rollSkinFromCase(selectedCase).copy(instanceId = UUID.randomUUID().toString())

                // Prepare reel items (35 items per reel)
                val pReel = mutableListOf<SkinItem>()
                val bReel = mutableListOf<SkinItem>()
                val pool = selectedCase.containedSkins

                for (i in 0 until 35) {
                    pReel.add(if (i == 25) playerWonSkin else pool.random())
                    bReel.add(if (i == 25) botWonSkin else pool.random())
                }

                playerReelList.clear()
                playerReelList.addAll(pReel)

                botReelList.clear()
                botReelList.addAll(bReel)

                playerReelOffset.snapTo(0f)
                botReelOffset.snapTo(0f)

                // Animate both reels simultaneously
                val pTarget = -(25 * 110f + Random.nextInt(10, 80).toFloat())
                val bTarget = -(25 * 110f + Random.nextInt(10, 80).toFloat())

                val tickJob = launch {
                    for (t in 0 until 25) {
                        soundEffects.playReelTick()
                        delay(70 + t * 4L)
                    }
                }

                launch {
                    playerReelOffset.animateTo(
                        targetValue = pTarget,
                        animationSpec = tween(2800, easing = CubicBezierEasing(0.1f, 0.85f, 0.25f, 1.0f))
                    )
                }

                launch {
                    botReelOffset.animateTo(
                        targetValue = bTarget,
                        animationSpec = tween(2800, easing = CubicBezierEasing(0.1f, 0.85f, 0.25f, 1.0f))
                    )
                }

                delay(3000)
                tickJob.cancel()

                playerDrops.add(playerWonSkin)
                botDrops.add(botWonSkin)
                soundEffects.playWinChime(playerWonSkin.price > botWonSkin.price)
                delay(1200)
            }

            // Determine winner
            val playerTotal = playerDrops.sumOf { it.price }
            val botTotal = botDrops.sumOf { it.price }

            val playerWon = if (selectedMode == BattleMode.STANDARD) {
                playerTotal >= botTotal
            } else {
                playerTotal <= botTotal
            }

            val allSkins = playerDrops.toList() + botDrops.toList()
            repository.finishCaseBattle(playerWon, allSkins)

            battleWinner = if (playerWon) profile.name else selectedDifficulty.botName
            isBattling = false
            showWinnerDialog = true

            if (playerWon) {
                soundEffects.playUpgradeSuccess()
            } else {
                soundEffects.playUpgradeFail()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("case_battle_screen")
    ) {
        // Banner Header
        Card(
            colors = CardDefaults.cardColors(containerColor = BgCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, FlameGold, RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(FlameGold),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "АРЕНА КЕЙС БАТЛОВ 1v1",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = FlameGold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Сразись с соперником: победитель забирает ВСЕ скины!",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Battle Stage: Player 1 vs Bot
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Player Side
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.5.dp, NeonCyan, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data("file:///android_asset/${profile.avatarAsset}")
                            .crossfade(true)
                            .build(),
                        contentDescription = profile.name,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, NeonCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = profile.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "ВЫ",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.sp,
                        color = NeonCyan
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = String.format("%.0f ₽", playerDrops.sumOf { it.price }),
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = FlameGold
                    )
                }
            }

            // VS Badge in Center
            Box(
                modifier = Modifier
                    .align(Alignment.CenterVertically)
                    .clip(CircleShape)
                    .background(CrimsonRed)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "VS",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    color = Color.White
                )
            }

            // Bot Side
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.5.dp, CrimsonRed, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(BgCardElevated)
                            .border(1.5.dp, CrimsonRed, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🤖",
                            fontSize = 24.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedDifficulty.botName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = selectedDifficulty.title,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.sp,
                        color = CrimsonRed
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = String.format("%.0f ₽", botDrops.sumOf { it.price }),
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = FlameGold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dual Spinning Reel (Visible during active battle)
        if (isBattling) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCardElevated),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, FlameGold, RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "РАУНД $currentRound / $battleRounds",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = FlameGold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Player 1 Reel
                    Text(
                        text = "Рулетка игрока:",
                        fontSize = 10.sp,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(65.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(BgDark)
                            .border(1.dp, NeonCyan, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier
                                .offset { IntOffset(playerReelOffset.value.toInt(), 0) }
                                .padding(horizontal = 140.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            playerReelList.forEach { skin ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgCard),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .width(70.dp)
                                        .height(55.dp)
                                        .border(1.dp, skin.rarity.color, RoundedCornerShape(4.dp))
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data("file:///android_asset/${skin.assetPath}")
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = null,
                                            modifier = Modifier.size(34.dp),
                                            contentScale = ContentScale.Fit
                                        )
                                        Text(
                                            text = skin.weaponName,
                                            fontSize = 7.sp,
                                            color = TextPrimary,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                        // Center pointer
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(65.dp)
                                .background(NeonCyan)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Bot Reel
                    Text(
                        text = "Рулетка соперника:",
                        fontSize = 10.sp,
                        color = CrimsonRed,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(65.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(BgDark)
                            .border(1.dp, CrimsonRed, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier
                                .offset { IntOffset(botReelOffset.value.toInt(), 0) }
                                .padding(horizontal = 140.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            botReelList.forEach { skin ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgCard),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .width(70.dp)
                                        .height(55.dp)
                                        .border(1.dp, skin.rarity.color, RoundedCornerShape(4.dp))
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data("file:///android_asset/${skin.assetPath}")
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = null,
                                            modifier = Modifier.size(34.dp),
                                            contentScale = ContentScale.Fit
                                        )
                                        Text(
                                            text = skin.weaponName,
                                            fontSize = 7.sp,
                                            color = TextPrimary,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                        // Center pointer
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(65.dp)
                                .background(CrimsonRed)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Battle Setup Controls (Active when not battling)
        if (!isBattling) {
            // Case Selector
            Text(
                text = "ВЫБЕРИТЕ КЕЙС ДЛЯ БАТЛА",
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                color = TextPrimary,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(GameCatalog.allCases.take(12), key = { it.id }) { c ->
                    val isSelected = c.id == selectedCase.id
                    Card(
                        onClick = { selectedCase = c },
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) BgCardElevated else BgCard),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .width(110.dp)
                            .border(if (isSelected) 2.dp else 1.dp, if (isSelected) NeonCyan else StrokeGlow, RoundedCornerShape(10.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data("file:///android_asset/${c.assetPath}")
                                    .crossfade(true)
                                    .build(),
                                contentDescription = c.name,
                                modifier = Modifier.size(60.dp),
                                contentScale = ContentScale.Fit
                            )
                            Text(
                                text = c.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = TextPrimary,
                                maxLines = 1
                            )
                            Text(
                                text = c.displayPrice,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = FlameGold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Rounds Selector: 1, 3, 5 rounds
            Text(
                text = "КОЛИЧЕСТВО РАУНДОВ",
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                color = TextPrimary,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 3, 5).forEach { r ->
                    val isSelected = r == battleRounds
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NeonCyan else BgCard)
                            .border(1.dp, if (isSelected) NeonCyan else StrokeGlow, RoundedCornerShape(8.dp))
                            .clickable { battleRounds = r }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$r ${if (r == 1) "раунд" else "раунда"}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isSelected) Color.Black else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Mode Selector: Классика vs Крейзи
            Text(
                text = "РЕЖИМ БАТЛА",
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                color = TextPrimary,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BattleMode.entries.forEach { mode ->
                    val isSelected = mode == selectedMode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) FlameGold else BgCard)
                            .border(1.dp, if (isSelected) FlameGold else StrokeGlow, RoundedCornerShape(8.dp))
                            .clickable { selectedMode = mode }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isSelected) Color.Black else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Start Battle Button
            Button(
                onClick = { startBattle() },
                enabled = profile.balance >= totalCost,
                colors = ButtonDefaults.buttonColors(
                    containerColor = FlameGold,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("start_case_battle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FlashOn,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "НАЧАТЬ БАТЛ ЗА ${String.format("%.0f", totalCost)} ₽",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Winner Dialog Overlay
    if (showWinnerDialog) {
        val playerTotal = playerDrops.sumOf { it.price }
        val botTotal = botDrops.sumOf { it.price }
        val isPlayerWinner = battleWinner == profile.name

        Dialog(onDismissRequest = { showWinnerDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, if (isPlayerWinner) NeonGreen else CrimsonRed, RoundedCornerShape(16.dp))
                    .testTag("battle_winner_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = if (isPlayerWinner) FlameGold else CrimsonRed,
                        modifier = Modifier.size(54.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isPlayerWinner) "ПОБЕДА В БАТЛЕ! 🏆" else "ПОРАЖЕНИЕ В БАТЛЕ",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = if (isPlayerWinner) NeonGreen else CrimsonRed
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isPlayerWinner) {
                            "Вы выбили больше и забрали ВСЕ скины соперника!"
                        } else {
                            "Соперник забрал дропы этого батла. Попробуйте еще!"
                        },
                        fontSize = 12.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Drops sum comparison
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BgDark)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Вы выбили", fontSize = 11.sp, color = TextMuted)
                            Text(text = String.format("%.0f ₽", playerTotal), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NeonCyan)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Соперник", fontSize = 11.sp, color = TextMuted)
                            Text(text = String.format("%.0f ₽", botTotal), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CrimsonRed)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showWinnerDialog = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FlameGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("close_battle_dialog_button")
                    ) {
                        Text(
                            text = "ПРОДОЛЖИТЬ",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
