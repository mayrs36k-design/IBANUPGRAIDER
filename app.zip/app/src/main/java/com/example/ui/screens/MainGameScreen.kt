package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.audio.SoundEffects
import com.example.data.GameRepository
import com.example.model.CaseItem
import com.example.model.SkinItem
import com.example.ui.components.LiveDropFeedBar
import com.example.ui.components.RewardedAdDialog
import com.example.ui.components.TopHeaderBar
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CsBlue
import com.example.ui.theme.CsGold
import com.example.ui.theme.CsGoldDark
import com.example.ui.theme.CsGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class GameTab(val title: String, val icon: ImageVector) {
    CASES("Кейсы", Icons.Default.Casino),
    UPGRADE("Апгрейд", Icons.Default.AutoAwesome),
    BATTLES("Батлы", Icons.Default.SportsEsports),
    FARM("Фармилка", Icons.Default.MonetizationOn),
    INVENTORY("Инвентарь", Icons.Default.Inventory2),
    CONTRACTS("Контракты", Icons.Default.Description)
}

@Composable
fun MainGameScreen(
    repository: GameRepository,
    soundEffects: SoundEffects,
    modifier: Modifier = Modifier
) {
    val profile by repository.profile.collectAsState()
    val liveDrops by repository.liveDrops.collectAsState()
    val settings by repository.settings.collectAsState()

    var currentTab by remember { mutableStateOf(GameTab.CASES) }
    var selectedCaseForOpen by remember { mutableStateOf<CaseItem?>(null) }
    var preselectedSkinForUpgrade by remember { mutableStateOf<SkinItem?>(null) }

    var isSoundOn by remember { mutableStateOf(soundEffects.isSoundEnabled()) }
    var showRewardedAdDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isDesktopWidth = maxWidth >= 700.dp

        if (isDesktopWidth) {
            // DESKTOP / PC VERSION: Split Layout with Desktop Sidebar (NavigationRail)
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BgDark)
            ) {
                // Desktop Sidebar
                NavigationRail(
                    containerColor = BgCard,
                    contentColor = TextSecondary,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(CsGold, CsGoldDark)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "⚡", fontSize = 22.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "IBAH",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = CsGold
                            )
                            Text(
                                text = "UPGRAIDER",
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = TextPrimary
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxHeight()
                        .border(1.dp, CardBorder)
                        .testTag("desktop_sidebar")
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    GameTab.entries.forEach { tab ->
                        val isSelected = currentTab == tab && selectedCaseForOpen == null
                        NavigationRailItem(
                            selected = isSelected,
                            onClick = {
                                selectedCaseForOpen = null
                                currentTab = tab
                            },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal
                                )
                            },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = CsGold,
                                indicatorColor = CsGold,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            ),
                            modifier = Modifier.testTag("desktop_nav_${tab.name.lowercase()}")
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Desktop Quick 10s Ad watch button
                    IconButton(
                        onClick = { showRewardedAdDialog = true },
                        modifier = Modifier
                            .padding(bottom = 12.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(CsGold)
                            .testTag("desktop_free_coins_ad_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.OndemandVideo,
                            contentDescription = "Смотреть рекламу 10 сек (+1 500 ₽)",
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Desktop Main Content Area with TopBar
                Column(modifier = Modifier.fillMaxSize()) {
                    TopHeaderBar(
                        profile = profile,
                        isSoundEnabled = isSoundOn,
                        isOfflineMode = settings.isOfflineMode,
                        onToggleSound = {
                            val next = !isSoundOn
                            isSoundOn = next
                            soundEffects.setSoundEnabled(next)
                        },
                        onAddBalanceClick = { showRewardedAdDialog = true },
                        onProfileClick = {
                            selectedCaseForOpen = null
                            currentTab = GameTab.INVENTORY
                        },
                        onSettingsClick = { showSettingsDialog = true }
                    )
                    LiveDropFeedBar(
                        drops = liveDrops,
                        isOfflineMode = settings.isOfflineMode,
                        onDropClick = {}
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(BgDark)
                    ) {
                        RenderGameScreenContent(
                            currentTab = currentTab,
                            selectedCaseForOpen = selectedCaseForOpen,
                            preselectedSkinForUpgrade = preselectedSkinForUpgrade,
                            repository = repository,
                            soundEffects = soundEffects,
                            onSelectCase = { selectedCaseForOpen = it },
                            onBackFromCase = { selectedCaseForOpen = null },
                            onNavigateToUpgradeWithSkin = { skin ->
                                preselectedSkinForUpgrade = skin
                                selectedCaseForOpen = null
                                currentTab = GameTab.UPGRADE
                            },
                            onNavigateToFarm = { currentTab = GameTab.FARM }
                        )
                    }
                }
            }
        } else {
            // MOBILE VERSION: Standard BottomBar Navigation
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                topBar = {
                    Column {
                        TopHeaderBar(
                            profile = profile,
                            isSoundEnabled = isSoundOn,
                            isOfflineMode = settings.isOfflineMode,
                            onToggleSound = {
                                val next = !isSoundOn
                                isSoundOn = next
                                soundEffects.setSoundEnabled(next)
                            },
                            onAddBalanceClick = { showRewardedAdDialog = true },
                            onProfileClick = {
                                selectedCaseForOpen = null
                                currentTab = GameTab.INVENTORY
                            },
                            onSettingsClick = { showSettingsDialog = true }
                        )
                        LiveDropFeedBar(
                            drops = liveDrops,
                            isOfflineMode = settings.isOfflineMode,
                            onDropClick = {}
                        )
                    }
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = BgCard,
                        contentColor = TextSecondary,
                        modifier = Modifier
                            .border(width = 1.dp, color = CardBorder)
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("bottom_navigation_bar")
                    ) {
                        GameTab.entries.forEach { tab ->
                            val isSelected = currentTab == tab && selectedCaseForOpen == null
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    selectedCaseForOpen = null
                                    currentTab = tab
                                },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.title,
                                        fontSize = 9.sp,
                                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CsGold,
                                    indicatorColor = CsGold,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(BgDark)
                ) {
                    RenderGameScreenContent(
                        currentTab = currentTab,
                        selectedCaseForOpen = selectedCaseForOpen,
                        preselectedSkinForUpgrade = preselectedSkinForUpgrade,
                        repository = repository,
                        soundEffects = soundEffects,
                        onSelectCase = { selectedCaseForOpen = it },
                        onBackFromCase = { selectedCaseForOpen = null },
                        onNavigateToUpgradeWithSkin = { skin ->
                            preselectedSkinForUpgrade = skin
                            selectedCaseForOpen = null
                            currentTab = GameTab.UPGRADE
                        },
                        onNavigateToFarm = { currentTab = GameTab.FARM }
                    )
                }
            }
        }
    }

    // 10-Second Ad Dialog for free coins
    if (showRewardedAdDialog) {
        RewardedAdDialog(
            rewardAmount = 1500.0,
            onRewardEarned = { amount ->
                repository.addBonusCoins(amount)
                soundEffects.playUpgradeSuccess()
            },
            onDismiss = { showRewardedAdDialog = false }
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            repository = repository,
            soundEffects = soundEffects,
            onDismiss = { showSettingsDialog = false }
        )
    }
}

@Composable
private fun RenderGameScreenContent(
    currentTab: GameTab,
    selectedCaseForOpen: CaseItem?,
    preselectedSkinForUpgrade: SkinItem?,
    repository: GameRepository,
    soundEffects: SoundEffects,
    onSelectCase: (CaseItem) -> Unit,
    onBackFromCase: () -> Unit,
    onNavigateToUpgradeWithSkin: (SkinItem) -> Unit,
    onNavigateToFarm: () -> Unit
) {
    if (selectedCaseForOpen != null) {
        CaseOpenScreen(
            caseItem = selectedCaseForOpen,
            repository = repository,
            soundEffects = soundEffects,
            onBack = onBackFromCase,
            onNavigateToUpgradeWithSkin = onNavigateToUpgradeWithSkin
        )
    } else {
        when (currentTab) {
            GameTab.CASES -> {
                CasesCatalogScreen(
                    onSelectCase = onSelectCase
                )
            }
            GameTab.UPGRADE -> {
                UpgradeScreen(
                    repository = repository,
                    soundEffects = soundEffects,
                    initialPreselectedSkin = preselectedSkinForUpgrade
                )
            }
            GameTab.BATTLES -> {
                CaseBattleScreen(
                    repository = repository,
                    soundEffects = soundEffects
                )
            }
            GameTab.FARM -> {
                FarmlingScreen(
                    repository = repository,
                    soundEffects = soundEffects
                )
            }
            GameTab.INVENTORY -> {
                InventoryScreen(
                    repository = repository,
                    soundEffects = soundEffects,
                    onNavigateToUpgrade = onNavigateToUpgradeWithSkin,
                    onNavigateToFarm = onNavigateToFarm
                )
            }
            GameTab.CONTRACTS -> {
                ContractsScreen(
                    repository = repository,
                    soundEffects = soundEffects
                )
            }
        }
    }
}
