package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.GameCatalog
import com.example.model.CaseItem
import com.example.ui.components.CaseCard
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardBorderHighlight
import com.example.ui.theme.CsGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CasesCatalogScreen(
    onSelectCase: (CaseItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val categories = remember {
        listOf("Все", "Серийные", "Именные", "Лимитированные", "Ножевые")
    }
    var selectedCategory by remember { mutableStateOf("Все") }
    var sortAscending by remember { mutableStateOf(true) }

    // Memorized, performance-optimized list of cases sorted ascending by price
    val displayedCases by remember(selectedCategory, sortAscending) {
        derivedStateOf {
            val baseList = if (selectedCategory == "Все") {
                GameCatalog.allCases
            } else {
                GameCatalog.allCases.filter { it.category.equals(selectedCategory, ignoreCase = true) }
            }
            if (sortAscending) {
                baseList.sortedBy { it.price }
            } else {
                baseList.sortedByDescending { it.price }
            }
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 150.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .testTag("cases_catalog_grid")
    ) {
        // Hero Banner Item spanning full width
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(125.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data("file:///android_asset/banners/main-desktop-N1hjs-46-extractpics.png")
                            .crossfade(false)
                            .build(),
                        contentDescription = "IBAHURPGRAIDER Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Category Filter Pills & Sort Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LazyRow(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(categories, key = { it }) { category ->
                            val isSelected = category == selectedCategory
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) CsGold else BgCard)
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) CsGold else CardBorder,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedCategory = category }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("category_pill_${category}")
                            ) {
                                Text(
                                    text = category,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
                                    fontSize = 11.sp,
                                    color = if (isSelected) Color.Black else TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Ascending/Descending sort indicator button
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BgCardElevated)
                            .border(1.dp, CardBorderHighlight, RoundedCornerShape(8.dp))
                            .clickable { sortAscending = !sortAscending }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("sort_price_button"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (sortAscending) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = "Сортировка по цене",
                            tint = CsGold,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (sortAscending) "По цене ↑" else "По цене ↓",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CsGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Section header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (selectedCategory == "Все") "ЯЩИКИ (ПО ВОЗРАСТАНИЮ ЦЕНЫ)" else "${selectedCategory.uppercase()} КЕЙСЫ",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "${displayedCases.size} кейсов",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Case Cards sorted strictly by price ascending
        items(displayedCases, key = { it.id }) { caseItem ->
            CaseCard(
                caseItem = caseItem,
                onClick = { onSelectCase(caseItem) }
            )
        }
    }
}
