package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.audio.SoundEffects
import com.example.data.GameRepository
import com.example.model.FarmUpgrade
import com.example.ui.components.RewardedAdDialog
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CsBlue
import com.example.ui.theme.CsGold
import com.example.ui.theme.CsGreen
import com.example.ui.theme.CsRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

data class FloatingCoinText(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isCrit: Boolean,
    val offsetX: Float,
    val offsetY: Float
)

@Composable
fun FarmlingScreen(
    repository: GameRepository,
    soundEffects: SoundEffects,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val profile by repository.profile.collectAsState()
    val upgrades by repository.farmUpgrades.collectAsState()

    val crateScale = remember { Animatable(1f) }
    val floatingTexts = remember { mutableStateListOf<FloatingCoinText>() }
    var dailyBonusClaimed by remember { mutableStateOf(false) }
    var showRewardedAd by remember { mutableStateOf(false) }

    fun handleCrateClick() {
        val isCrit = Random.nextDouble() < 0.12
        val base = repository.clickFarm()
        val earned = if (isCrit) {
            repository.addBonusCoins(base * 2.0)
            base * 3.0
        } else base

        soundEffects.playCoinClick()

        scope.launch {
            crateScale.snapTo(0.94f)
            crateScale.animateTo(1f, animationSpec = spring(dampingRatio = 0.5f, stiffness = 800f))
        }

        // Limit floating items to max 3 for performance
        if (floatingTexts.size > 3) {
            floatingTexts.removeAt(0)
        }
        val item = FloatingCoinText(
            text = if (isCrit) "+${String.format("%.1f", earned)} ₽ КРИТ!" else "+${String.format("%.1f", earned)} ₽",
            isCrit = isCrit,
            offsetX = Random.nextInt(-40, 40).toFloat(),
            offsetY = Random.nextInt(-30, 10).toFloat()
        )
        floatingTexts.add(item)
        scope.launch {
            delay(600)
            floatingTexts.remove(item)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(12.dp)
            .testTag("farm_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Rewarded Ad Card: Watch 10s ad to get free money!
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CsGold, RoundedCornerShape(12.dp))
                    .testTag("rewarded_ad_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CsGold),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.OndemandVideo,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "РЕКЛАМА (10 СЕК) ⚡",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = CsGold
                            )
                            Text(
                                text = "Посмотрите ролик 10 сек и получите +1 500 ₽!",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { showRewardedAd = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CsGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("watch_ad_10s_button")
                    ) {
                        Text(
                            text = "+1 500 ₽",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Daily Bonus Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BgCardElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = null,
                                tint = CsGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ЕЖЕДНЕВНЫЙ БОНУС",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = TextPrimary
                            )
                            Text(
                                text = if (dailyBonusClaimed) "Уже получено сегодня" else "+500 ₽ на баланс",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (!dailyBonusClaimed) {
                                repository.addBonusCoins(500.0)
                                soundEffects.playCoinClick()
                                dailyBonusClaimed = true
                            }
                        },
                        enabled = !dailyBonusClaimed,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BgCardElevated,
                            contentColor = CsGold,
                            disabledContainerColor = BgCardElevated.copy(alpha = 0.5f),
                            disabledContentColor = TextMuted
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                            .testTag("claim_daily_bonus_button")
                    ) {
                        Text(
                            text = if (dailyBonusClaimed) "ВЗЯТО" else "ЗАБРАТЬ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Tap-to-Earn Interactive Container Area
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCardElevated),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorder, RoundedCornerShape(14.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "КЛИКЕР-ФАРМИЛКА МОНЕТ",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = CsGold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Тапайте по ящику, чтобы майнить монеты на открытие кейсов",
                        fontSize = 11.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // The Clickable Crate
                    Box(
                        modifier = Modifier
                            .size(170.dp)
                            .scale(crateScale.value)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                handleCrateClick()
                            }
                            .testTag("farm_crate_click_target"),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data("file:///android_asset/cases/case_01.webp")
                                .crossfade(false)
                                .build(),
                            contentDescription = "Фарм кейс",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Floating coins feedback
                        floatingTexts.forEach { ft ->
                            Text(
                                text = ft.text,
                                fontSize = if (ft.isCrit) 16.sp else 13.sp,
                                fontWeight = FontWeight.Black,
                                color = if (ft.isCrit) CsRed else CsGold,
                                modifier = Modifier.offset {
                                    IntOffset(ft.offsetX.toInt(), ft.offsetY.toInt())
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Stats indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TouchApp, contentDescription = null, tint = CsGold, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(text = "За тап", fontSize = 11.sp, color = TextMuted)
                            }
                            Text(
                                text = "+${String.format("%.1f", profile.clickPower)} ₽",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = CsGold
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = CsBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(text = "Пассив / сек", fontSize = 11.sp, color = TextMuted)
                            }
                            Text(
                                text = "+${String.format("%.1f", profile.passiveIncomePerSec)} ₽",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = CsBlue
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = CsGreen, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(text = "Баланс", fontSize = 11.sp, color = TextMuted)
                            }
                            Text(
                                text = String.format("%.0f ₽", profile.balance),
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = CsGreen
                            )
                        }
                    }
                }
            }
        }

        // Upgrades Header
        item {
            Text(
                text = "ПРОКАЧКА ФАРМА",
                fontWeight = FontWeight.Black,
                fontSize = 13.sp,
                color = TextPrimary,
                letterSpacing = 0.5.sp
            )
        }

        // Upgrade items list
        items(upgrades, key = { it.id }) { upgrade ->
            val canAfford = profile.balance >= upgrade.currentCost
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = upgrade.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Ур. ${upgrade.level}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = CsGold
                            )
                        }
                        Text(
                            text = upgrade.description,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (repository.buyFarmUpgrade(upgrade.id)) {
                                soundEffects.playCoinClick()
                            }
                        },
                        enabled = canAfford,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (canAfford) CsGold else BgCardElevated,
                            contentColor = if (canAfford) Color.Black else TextMuted
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("buy_upgrade_${upgrade.id}")
                    ) {
                        Text(
                            text = String.format("%.0f ₽", upgrade.currentCost),
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }

    if (showRewardedAd) {
        RewardedAdDialog(
            rewardAmount = 1500.0,
            onRewardEarned = { amount ->
                repository.addBonusCoins(amount)
                soundEffects.playUpgradeSuccess()
            },
            onDismiss = { showRewardedAd = false }
        )
    }
}
