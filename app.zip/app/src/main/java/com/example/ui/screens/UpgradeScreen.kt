package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.audio.SoundEffects
import com.example.data.GameCatalog
import com.example.data.GameRepository
import com.example.model.Rarity
import com.example.model.SkinItem
import com.example.ui.components.SkinCard
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.FlameGold
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StrokeGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun UpgradeScreen(
    repository: GameRepository,
    soundEffects: SoundEffects,
    initialPreselectedSkin: SkinItem? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val profile by repository.profile.collectAsState()
    val inventory by repository.inventory.collectAsState()

    // Upgrading items selection (up to 5 items)
    val selectedInventory = remember { mutableStateListOf<SkinItem>() }
    var addedCash by remember { mutableDoubleStateOf(0.0) }

    // Preselect item if navigated from Case Open
    remember(initialPreselectedSkin) {
        if (initialPreselectedSkin != null && selectedInventory.none { it.instanceId == initialPreselectedSkin.instanceId }) {
            selectedInventory.clear()
            selectedInventory.add(initialPreselectedSkin)
        }
    }

    // Target skin selection
    var targetSkin by remember {
        mutableStateOf<SkinItem>(
            GameCatalog.allSkins.firstOrNull { it.rarity == Rarity.CLASSIFIED }
                ?: GameCatalog.allSkins.random()
        )
    }

    var catalogSearchQuery by remember { mutableStateOf("") }
    var isSpinning by remember { mutableStateOf(false) }
    var lastUpgradeResult by remember { mutableStateOf<GameRepository.UpgradeResult?>(null) }
    var showResultDialog by remember { mutableStateOf(false) }

    // Needle rotation angle (degrees: 0 to 360 * n)
    val needleAngle = remember { Animatable(0f) }

    // Total input value
    val totalInputValue = selectedInventory.sumOf { it.price } + addedCash
    // Calculated odds with 98% RTP
    val calculatedOdds = if (targetSkin.price > 0 && totalInputValue > 0) {
        ((totalInputValue / targetSkin.price) * 0.98).coerceIn(0.01, 0.85)
    } else 0.0

    val oddsPercentage = calculatedOdds * 100.0

    fun selectMultiplier(multiplier: Double) {
        if (totalInputValue <= 0) return
        val targetPrice = totalInputValue * multiplier
        val closest = GameCatalog.allSkins.minByOrNull { kotlin.math.abs(it.price - targetPrice) }
        if (closest != null) {
            targetSkin = closest
        }
    }

    fun selectOddsTarget(targetOddsPercentage: Double) {
        if (totalInputValue <= 0) return
        val desiredOdds = (targetOddsPercentage / 100.0).coerceIn(0.01, 0.85)
        val targetPrice = (totalInputValue * 0.98) / desiredOdds
        val closest = GameCatalog.allSkins.minByOrNull { kotlin.math.abs(it.price - targetPrice) }
        if (closest != null) {
            targetSkin = closest
        }
    }

    fun startUpgrade() {
        if (isSpinning || calculatedOdds <= 0.0) return

        val inputIds = selectedInventory.map { it.instanceId }
        val result = repository.executeUpgrade(inputIds, targetSkin, addedCash)
        lastUpgradeResult = result
        isSpinning = true

        scope.launch {
            // Compute stop angle:
            // Arc starts at -90 degrees (top). Green sector covers (calculatedOdds * 360) degrees clockwise.
            val greenArcDegrees = (result.odds * 360.0).toFloat()
            val finalAngleWithinCircle = if (result.success) {
                // Land safely in green sector: from 10 deg to (greenArcDegrees - 10)
                Random.nextDouble(5.0, (greenArcDegrees - 5.0).coerceAtLeast(6.0)).toFloat()
            } else {
                // Land in dark sector: from greenArcDegrees to 355 deg
                Random.nextDouble((greenArcDegrees + 5.0).coerceAtMost(350.0), 355.0).toFloat()
            }

            // Total spin = 4 full rotations + final angle
            val targetDegrees = 360f * 5 + finalAngleWithinCircle
            needleAngle.snapTo(0f)

            var lastTone = 0
            val soundJob = launch {
                while (isSpinning) {
                    val p = (needleAngle.value / targetDegrees).coerceIn(0f, 1f)
                    soundEffects.playUpgradeSweep(p)
                    delay(30)
                }
            }

            needleAngle.animateTo(
                targetValue = targetDegrees,
                animationSpec = tween(
                    durationMillis = 3800,
                    easing = CubicBezierEasing(0.15f, 0.9f, 0.25f, 1.0f)
                )
            )

            soundJob.cancel()
            isSpinning = false
            delay(150)

            if (result.success) {
                soundEffects.playUpgradeSuccess()
            } else {
                soundEffects.playUpgradeFail()
            }

            showResultDialog = true
            selectedInventory.clear()
            addedCash = 0.0
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("upgrade_screen")
    ) {
        // Title
        Text(
            text = "МОДЕРНИЗАЦИЯ ОРУЖИЯ 2.0",
            fontWeight = FontWeight.Black,
            fontSize = 17.sp,
            color = FlameGold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Top Upgrade Stage: Left (Inputs) | Center (Radial Gauge) | Right (Target)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // LEFT BOX: Input Items
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(230.dp)
                    .border(1.dp, StrokeGlow, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "НА АПГРЕЙД (${selectedInventory.size}/5)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )

                    if (selectedInventory.isNotEmpty()) {
                        val primaryInput = selectedInventory.first()
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data("file:///android_asset/${primaryInput.assetPath}")
                                .crossfade(true)
                                .build(),
                            contentDescription = primaryInput.fullName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(75.dp)
                        )
                        Text(
                            text = primaryInput.fullName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryInput.rarity.color,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(75.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BgDark)
                                .border(1.dp, StrokeGlow, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Выберите\nскин ниже",
                                fontSize = 10.sp,
                                color = TextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Cash slider to add balance
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Баланс:",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                            Text(
                                text = "+${String.format("%.0f", addedCash)} ₽",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = FlameGold
                            )
                        }
                        Slider(
                            value = addedCash.toFloat(),
                            onValueChange = { addedCash = it.toDouble() },
                            valueRange = 0f..profile.balance.toFloat().coerceAtLeast(10f),
                            colors = SliderDefaults.colors(
                                thumbColor = FlameGold,
                                activeTrackColor = FlameGold,
                                inactiveTrackColor = BgDark
                            ),
                            modifier = Modifier.height(24.dp)
                        )
                    }

                    // Total Input Value Badge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(BgDark)
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Сумма: ${if (totalInputValue >= 1000) String.format("%,.0f ₽", totalInputValue) else String.format("%.2f ₽", totalInputValue)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = FlameGold
                        )
                    }
                }
            }

            // CENTER: Circular Speedometer Gauge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(135.dp)
            ) {
                Box(
                    modifier = Modifier.size(135.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val currentRotation = needleAngle.value % 360f

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 14.dp.toPx()
                        val arcRadius = (size.minDimension - strokeWidth) / 2
                        val centerOffset = Offset(size.width / 2, size.height / 2)

                        // Background dark circle track
                        drawCircle(
                            color = Color(0xFF1E2133),
                            radius = arcRadius,
                            center = centerOffset,
                            style = Stroke(width = strokeWidth)
                        )

                        // Green neon success odds arc
                        val sweepAngle = (calculatedOdds * 360.0).toFloat().coerceIn(0f, 360f)
                        if (sweepAngle > 0f) {
                            drawArc(
                                brush = Brush.sweepGradient(
                                    listOf(NeonGreen, FlameGold, NeonGreen)
                                ),
                                startAngle = -90f,
                                sweepAngle = sweepAngle,
                                useCenter = false,
                                topLeft = Offset(centerOffset.x - arcRadius, centerOffset.y - arcRadius),
                                size = Size(arcRadius * 2, arcRadius * 2),
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }

                        // Rotating Needle pointer
                        val angleRad = Math.toRadians((currentRotation - 90.0)).toFloat()
                        val needleLength = arcRadius - 4.dp.toPx()
                        val needleEnd = Offset(
                            x = centerOffset.x + needleLength * cos(angleRad),
                            y = centerOffset.y + needleLength * sin(angleRad)
                        )

                        drawLine(
                            color = FlameGold,
                            start = centerOffset,
                            end = needleEnd,
                            strokeWidth = 3.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Center hub pin
                        drawCircle(
                            color = FlameGold,
                            radius = 5.dp.toPx(),
                            center = centerOffset
                        )
                    }

                    // Gauge Center Text
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Text(
                            text = String.format("%.2f%%", oddsPercentage),
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = if (oddsPercentage > 45) NeonGreen else FlameGold
                        )
                        Text(
                            text = when {
                                oddsPercentage >= 70 -> "очень высокий"
                                oddsPercentage >= 40 -> "высокий шанс"
                                oddsPercentage >= 20 -> "средний шанс"
                                else -> "рискованно"
                            },
                            fontSize = 9.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Big ПРОКАЧАТЬ Button
                Button(
                    onClick = { startUpgrade() },
                    enabled = !isSpinning && totalInputValue > 0 && calculatedOdds > 0,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FlameGold,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("execute_upgrade_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "ПРОКАЧАТЬ",
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }
            }

            // RIGHT BOX: Target Skin
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(230.dp)
                    .border(1.dp, StrokeGlow, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ХОЧУ ПОЛУЧИТЬ",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )

                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data("file:///android_asset/${targetSkin.assetPath}")
                            .crossfade(true)
                            .build(),
                        contentDescription = targetSkin.fullName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size(75.dp)
                    )

                    Text(
                        text = targetSkin.fullName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = targetSkin.rarity.color,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    // Target Price
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(BgDark)
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = targetSkin.displayPrice,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = FlameGold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Multiplier / Odds buttons row (x2, x5, x10, 20%, 50%, 75%)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("x2" to 2.0, "x5" to 5.0, "x10" to 10.0).forEach { (label, mult) ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(BgCard)
                        .border(1.dp, StrokeGlow, RoundedCornerShape(6.dp))
                        .clickable { selectMultiplier(mult) }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )
                }
            }

            listOf("20%" to 20.0, "50%" to 50.0, "75%" to 75.0).forEach { (label, pct) ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(BgCard)
                        .border(1.dp, StrokeGlow, RoundedCornerShape(6.dp))
                        .clickable { selectOddsTarget(pct) }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FlameGold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Bottom Section: Inventory Items (Мои предметы) & Target Catalog Picker
        Text(
            text = "МОИ ПРЕДМЕТЫ НА ВЫБОР",
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
            color = TextPrimary,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        if (inventory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(BgCard),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Инвентарь пуст. Откройте кейс или пополните баланс!",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        } else {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(inventory, key = { it.instanceId }) { skin ->
                    val isSelected = selectedInventory.any { it.instanceId == skin.instanceId }
                    Box(modifier = Modifier.width(110.dp)) {
                        SkinCard(
                            skin = skin,
                            isSelected = isSelected,
                            showSelectAction = true,
                            onClick = {
                                if (isSelected) {
                                    selectedInventory.removeAll { it.instanceId == skin.instanceId }
                                } else if (selectedInventory.size < 5) {
                                    selectedInventory.add(skin)
                                }
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Target Skins Catalog Picker
        Text(
            text = "КАТАЛОГ ОРУЖИЯ ДЛЯ АПГРЕЙДА",
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
            color = TextPrimary,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        val catalogFiltered = remember(catalogSearchQuery) {
            if (catalogSearchQuery.isBlank()) {
                GameCatalog.allSkins
            } else {
                GameCatalog.allSkins.filter {
                    it.fullName.contains(catalogSearchQuery, ignoreCase = true)
                }
            }
        }

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(catalogFiltered.take(30), key = { it.id }) { skin ->
                val isTarget = targetSkin.id == skin.id
                Box(modifier = Modifier.width(110.dp)) {
                    SkinCard(
                        skin = skin,
                        isSelected = isTarget,
                        showSelectAction = false,
                        onClick = { targetSkin = skin }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Result Dialog (Success or Cashback Fail)
    if (showResultDialog) {
        val result = lastUpgradeResult
        Dialog(onDismissRequest = { showResultDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        2.dp,
                        if (result?.success == true) NeonGreen else CrimsonRed,
                        RoundedCornerShape(16.dp)
                    )
                    .testTag("upgrade_result_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (result?.success == true && result.wonSkin != null) {
                        Text(
                            text = "УСПЕШНЫЙ АПГРЕЙД! 🎉",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = NeonGreen
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data("file:///android_asset/${result.wonSkin.assetPath}")
                                .crossfade(true)
                                .build(),
                            contentDescription = result.wonSkin.fullName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(110.dp)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = result.wonSkin.fullName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )

                        Text(
                            text = result.wonSkin.displayPrice,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = FlameGold
                        )
                    } else {
                        Text(
                            text = "УВЫ, НЕ ПОВЕЗЛО...",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = CrimsonRed
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Выпал сектор неудачи. Не расстраивайтесь!",
                            fontSize = 12.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Cashback
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(BgDark)
                                .padding(10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Кэшбек возвращен: +${String.format("%.2f", result?.cashback ?: 0.0)} ₽",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = FlameGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showResultDialog = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FlameGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("close_upgrade_dialog_button")
                    ) {
                        Text(
                            text = "ОТЛИЧНО",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
