package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.CaseItem
import com.example.model.LiveDrop
import com.example.model.PlayerProfile
import com.example.model.Rarity
import com.example.model.SkinItem
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.BgInput
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardBorderHighlight
import com.example.ui.theme.CsBlue
import com.example.ui.theme.CsGold
import com.example.ui.theme.CsGoldDark
import com.example.ui.theme.CsGreen
import com.example.ui.theme.CsRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun TopHeaderBar(
    profile: PlayerProfile,
    isSoundEnabled: Boolean,
    isOfflineMode: Boolean,
    onToggleSound: () -> Unit,
    onAddBalanceClick: () -> Unit,
    onProfileClick: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Surface(
        color = BgCard,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = CardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo: IBAH UPGRAIDER
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onProfileClick() }
                    .padding(2.dp)
                    .testTag("brand_logo")
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(CsGold, CsGoldDark)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "⚡",
                        fontSize = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "IBAH",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = CsGold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "UPGRAIDER",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = TextPrimary,
                            letterSpacing = 0.5.sp
                        )
                    }
                    if (isOfflineMode) {
                        Text(
                            text = "● ОФЛАЙН РЕЖИМ",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            color = CsGold,
                            letterSpacing = 0.5.sp
                        )
                    } else {
                        Text(
                            text = "CS2 TACTICAL DROPPER",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMuted,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            // Right side: Free Coins Ad Button, Balance, Settings, Avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Free Coins via 10-sec ad button
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(BgInput)
                        .border(1.dp, CsGold.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
                        .clickable { onAddBalanceClick() }
                        .padding(start = 8.dp, end = 4.dp, top = 3.dp, bottom = 3.dp)
                        .testTag("balance_chip"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🪙",
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = String.format("%,.0f ₽", profile.balance),
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        color = CsGold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(CsGold),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Реклама 10 сек за монеты",
                            tint = Color.Black,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Settings Button
                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Настройки",
                        tint = if (isOfflineMode) CsGold else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // User Avatar
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .border(1.dp, CardBorderHighlight, CircleShape)
                        .clickable { onProfileClick() }
                        .testTag("user_avatar_button")
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data("file:///android_asset/${profile.avatarAsset}")
                            .crossfade(false)
                            .build(),
                        contentDescription = profile.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@Composable
fun LiveDropFeedBar(
    drops: List<LiveDrop>,
    isOfflineMode: Boolean,
    onDropClick: (LiveDrop) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Surface(
        color = BgDark,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = CardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(BgCardElevated)
                    .border(1.dp, CardBorder, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (isOfflineMode) "ОФЛАЙН ДРОПЫ" else "LIVE ДРОПЫ",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    color = CsGold
                )
            }

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(end = 8.dp)
            ) {
                items(drops, key = { it.id }) { drop ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BgCard)
                            .border(1.dp, drop.skin.rarity.color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .clickable { onDropClick(drop) }
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data("file:///android_asset/${drop.skin.assetPath}")
                                    .crossfade(false)
                                    .build(),
                                contentDescription = drop.skin.fullName,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        Column {
                            Text(
                                text = drop.userName,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = drop.skin.displayPrice,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black,
                                color = CsGold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CaseCard(
    caseItem: CaseItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = BgCard),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .testTag("case_card_${caseItem.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Case Category Tag & Item Count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = caseItem.category.uppercase(),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = CsGold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = caseItem.itemsCountText,
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 3D Case Box Graphic
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data("file:///android_asset/${caseItem.assetPath}")
                        .crossfade(false)
                        .build(),
                    contentDescription = caseItem.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Case Title
            Text(
                text = caseItem.name,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Price Button (Tactical Gold)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(CsGold, CsGoldDark)
                        )
                    )
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = caseItem.displayPrice,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    color = Color.Black
                )
            }
        }
    }
}

@Composable
fun SkinCard(
    skin: SkinItem,
    onClick: () -> Unit = {},
    isSelected: Boolean = false,
    showSelectAction: Boolean = false,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) CsGreen else skin.rarity.color.copy(alpha = 0.5f),
        animationSpec = tween(150),
        label = "skin_border"
    )

    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = if (isSelected) BgCardElevated else BgCard),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(8.dp))
            .testTag("skin_card_${skin.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top badges (StatTrak and wear)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (skin.isStatTrak) {
                    Text(
                        text = "ST™",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CsGold
                    )
                } else {
                    Spacer(modifier = Modifier.width(4.dp))
                }

                if (showSelectAction && isSelected) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(CsGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Выбрано",
                            tint = Color.Black,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                } else {
                    Text(
                        text = skin.rarity.title,
                        fontSize = 9.sp,
                        color = skin.rarity.color,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Weapon Skin Image
            Box(
                modifier = Modifier.size(80.dp),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data("file:///android_asset/${skin.assetPath}")
                        .crossfade(false)
                        .build(),
                    contentDescription = skin.fullName,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Weapon Name
            Text(
                text = skin.weaponName,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Skin Name
            Text(
                text = skin.skinName,
                fontSize = 10.sp,
                color = skin.rarity.color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Price
            Text(
                text = skin.displayPrice,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp,
                color = CsGold
            )
        }
    }
}

/**
 * 10-Second Rewarded Ad Dialog simulator requested by the user:
 * "сделай чтоб бы получать бесплатные деньги надо смотреть рекламу 10 секунд"
 */
@Composable
fun RewardedAdDialog(
    rewardAmount: Double = 1000.0,
    onRewardEarned: (Double) -> Unit,
    onDismiss: () -> Unit
) {
    var secondsLeft by remember { mutableIntStateOf(10) }
    var isCompleted by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (secondsLeft > 0) {
            delay(1000L)
            secondsLeft -= 1
        }
        isCompleted = true
    }

    val progress by animateFloatAsState(
        targetValue = (10 - secondsLeft) / 10f,
        animationSpec = tween(durationMillis = 1000, easing = LinearEasing),
        label = "ad_progress"
    )

    Dialog(
        onDismissRequest = {
            if (isCompleted) onDismiss()
        },
        properties = DialogProperties(
            dismissOnBackPress = isCompleted,
            dismissOnClickOutside = false
        )
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BgCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, if (isCompleted) CsGreen else CsGold, RoundedCornerShape(16.dp))
                .testTag("rewarded_ad_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isCompleted) CsGreen else CsGold)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (isCompleted) "ПРОСМОТР ЗАВЕРШЕН" else "РЕКЛАМА СПОНСОРА",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.Black
                        )
                    }

                    Text(
                        text = if (isCompleted) "ГОТОВО" else "${secondsLeft} сек",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isCompleted) CsGreen else CsGold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Ad Showcase Simulation Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BgDark)
                        .border(1.dp, CardBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Text(
                            text = "CS2 MARKETCAP & CASE BATTLE",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = CsGold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "🎁 Заберите уникальные скины и кейсы по лучшим ценам рынка!",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = CsGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Награда: +${String.format("%,.0f", rewardAmount)} ₽",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = CsGreen
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Progress Bar
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (isCompleted) CsGreen else CsGold,
                    trackColor = BgCardElevated,
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (isCompleted) {
                    Button(
                        onClick = {
                            onRewardEarned(rewardAmount)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CsGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("claim_ad_reward_button")
                    ) {
                        Text(
                            text = "ЗАБРАТЬ +${String.format("%,.0f", rewardAmount)} ₽",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BgCardElevated)
                            .border(1.dp, CardBorder, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Осталось смотреть: $secondsLeft сек...",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}
