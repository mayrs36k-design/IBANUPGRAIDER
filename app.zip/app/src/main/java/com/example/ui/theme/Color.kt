package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic CS2 / Steam Tactical Dark Color System (No gaudy neon!)
val BgDark = Color(0xFF101318)
val BgCard = Color(0xFF171B23)
val BgCardElevated = Color(0xFF202632)
val BgInput = Color(0xFF13161F)
val CardBorder = Color(0xFF282F3E)
val CardBorderHighlight = Color(0xFF3A4458)

// Tactical Accents (CS2 Amber Gold, Covert Red, Special Gold)
val CsGold = Color(0xFFE5A93C)
val CsGoldDark = Color(0xFFB57D22)
val CsBlue = Color(0xFF4B69FF)
val CsSteel = Color(0xFF6B82A8)
val CsGreen = Color(0xFF43B581)
val CsRed = Color(0xFFEB4B4B)
val CsPink = Color(0xFFD32CE6)
val CsPurple = Color(0xFF8847FF)
val CsSpecialGold = Color(0xFFFFD700)

val TextPrimary = Color(0xFFF0F3F8)
val TextSecondary = Color(0xFF9AA4B8)
val TextMuted = Color(0xFF626E84)

// Compatibility aliases mapped to clean tactical colors
val NeonCyan = CsGold
val NeonPurple = CsPurple
val FlameGold = CsGold
val NeonGreen = CsGreen
val CrimsonRed = CsRed
val StrokeGlow = CardBorder
val StrokeGold = CsGold
