package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.SignalWifiOff
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.audio.SoundEffects
import com.example.data.GameCatalog
import com.example.data.GameRepository
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.FlameGold
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StrokeGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsDialog(
    repository: GameRepository,
    soundEffects: SoundEffects,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val settings by repository.settings.collectAsState()
    val accounts by repository.accounts.collectAsState()
    val activeAccountId by repository.activeAccountId.collectAsState()

    var showCreateAccountDialog by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BgCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, StrokeGlow, RoundedCornerShape(16.dp))
                .testTag("settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header with Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "НАСТРОЙКИ ИГРЫ",
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        color = FlameGold,
                        letterSpacing = 1.sp
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Закрыть",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.height(420.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. OFFLINE MODE CARD
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (settings.isOfflineMode) Color(0xFF221A15) else BgCardElevated
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (settings.isOfflineMode) FlameGold else StrokeGlow,
                                    RoundedCornerShape(12.dp)
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (settings.isOfflineMode) FlameGold else BgDark),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SignalWifiOff,
                                            contentDescription = null,
                                            tint = if (settings.isOfflineMode) Color.Black else TextMuted,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Офлайн режим",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = TextPrimary
                                            )
                                            if (settings.isOfflineMode) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(FlameGold.copy(alpha = 0.2f))
                                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = "ВКЛЮЧЕН",
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = FlameGold
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = if (settings.isOfflineMode) {
                                                "Автономная работа: сетевая лента дропов отключена, данные строго на устройстве"
                                            } else {
                                                "Онлайн симуляция: лента дропов и батлы активны"
                                            },
                                            fontSize = 10.sp,
                                            color = TextMuted
                                        )
                                    }
                                }

                                Switch(
                                    checked = settings.isOfflineMode,
                                    onCheckedChange = { repository.setOfflineMode(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = FlameGold,
                                        uncheckedThumbColor = TextMuted,
                                        uncheckedTrackColor = BgDark
                                    ),
                                    modifier = Modifier.testTag("offline_mode_switch")
                                )
                            }
                        }
                    }

                    // 2. ACCOUNT SYSTEM SECTION
                    item {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "СИСТЕМА АККАУНТОВ (${accounts.size})",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = NeonCyan,
                                    letterSpacing = 0.5.sp
                                )

                                Button(
                                    onClick = { showCreateAccountDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonPurple,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .height(28.dp)
                                        .testTag("create_new_account_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PersonAdd,
                                        contentDescription = null,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Новый",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // List of Accounts
                    items(accounts, key = { it.id }) { acc ->
                        val isActive = acc.id == activeAccountId
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isActive) BgCardElevated else BgDark
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (isActive) NeonGreen else StrokeGlow,
                                    RoundedCornerShape(10.dp)
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context)
                                            .data("file:///android_asset/${acc.avatarAsset}")
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = acc.name,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .border(
                                                1.5.dp,
                                                if (isActive) NeonGreen else StrokeGlow,
                                                CircleShape
                                            ),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = acc.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = TextPrimary
                                            )
                                            if (isActive) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "• АКТИВЕН",
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Black,
                                                    color = NeonGreen
                                                )
                                            }
                                        }
                                        Text(
                                            text = "Баланс: ${acc.displayBalance} • ${acc.inventory.size} скинов",
                                            fontSize = 10.sp,
                                            color = FlameGold
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (!isActive) {
                                        Button(
                                            onClick = {
                                                repository.switchAccount(acc.id)
                                                soundEffects.playCoinClick()
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = NeonCyan,
                                                contentColor = Color.Black
                                            ),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier
                                                .height(28.dp)
                                                .testTag("switch_to_${acc.id}")
                                        ) {
                                            Text(
                                                text = "Войти",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }

                                    if (accounts.size > 1) {
                                        IconButton(
                                            onClick = { repository.deleteAccount(acc.id) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Удалить",
                                                tint = CrimsonRed,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 3. SOUND & HAPTICS SETTINGS
                    item {
                        Text(
                            text = "ЗВУК И ЭФФЕКТЫ",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            color = NeonCyan,
                            letterSpacing = 0.5.sp
                        )
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgCardElevated),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.VolumeUp,
                                            contentDescription = null,
                                            tint = NeonCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Звуковые эффекты рулетки",
                                            fontSize = 12.sp,
                                            color = TextPrimary
                                        )
                                    }
                                    Switch(
                                        checked = soundEffects.isSoundEnabled(),
                                        onCheckedChange = { soundEffects.setSoundEnabled(it) }
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Vibration,
                                            contentDescription = null,
                                            tint = FlameGold,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Виброотклик (Haptics)",
                                            fontSize = 12.sp,
                                            color = TextPrimary
                                        )
                                    }
                                    Switch(
                                        checked = soundEffects.isHapticsEnabled(),
                                        onCheckedChange = { soundEffects.setHapticsEnabled(it) }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FlameGold,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                ) {
                    Text(
                        text = "СОХРАНИТЬ И ВЫЙТИ",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }

    // Dialog for creating a new Account
    if (showCreateAccountDialog) {
        var accName by remember { mutableStateOf("") }
        var selectedAvatar by remember { mutableStateOf(GameCatalog.avatarAssets.random()) }

        Dialog(onDismissRequest = { showCreateAccountDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StrokeGlow, RoundedCornerShape(14.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "СОЗДАНИЕ АККАУНТА",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = FlameGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = accName,
                        onValueChange = { accName = it.take(18) },
                        label = { Text("Имя нового аккаунта") },
                        placeholder = { Text("Например: S1mple_fan") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Выберите аватар:",
                        fontSize = 11.sp,
                        color = TextMuted,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(GameCatalog.avatarAssets.take(12)) { av ->
                            val isChosen = av == selectedAvatar
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .border(
                                        if (isChosen) 2.dp else 1.dp,
                                        if (isChosen) NeonGreen else StrokeGlow,
                                        CircleShape
                                    )
                                    .clickable { selectedAvatar = av }
                            ) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data("file:///android_asset/$av")
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showCreateAccountDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = BgCardElevated),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Отмена")
                        }

                        Button(
                            onClick = {
                                if (accName.isNotBlank()) {
                                    repository.createAccount(
                                        name = accName,
                                        avatarAsset = selectedAvatar,
                                        initialBalance = 5000.0
                                    )
                                    soundEffects.playUpgradeSuccess()
                                }
                                showCreateAccountDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FlameGold,
                                contentColor = Color.Black
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Создать")
                        }
                    }
                }
            }
        }
    }
}
