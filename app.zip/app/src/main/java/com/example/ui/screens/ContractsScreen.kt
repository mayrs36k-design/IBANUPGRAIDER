package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.audio.SoundEffects
import com.example.data.GameRepository
import com.example.model.Rarity
import com.example.model.SkinItem
import com.example.ui.components.SkinCard
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.FlameGold
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StrokeGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ContractsScreen(
    repository: GameRepository,
    soundEffects: SoundEffects,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val inventory by repository.inventory.collectAsState()

    val selectedSkins = remember { mutableStateListOf<SkinItem>() }
    var isSigning by remember { mutableStateOf(false) }
    var contractResultSkin by remember { mutableStateOf<SkinItem?>(null) }

    val totalContractValue = selectedSkins.sumOf { it.price }

    fun executeSignContract() {
        if (selectedSkins.size !in 3..10 || isSigning) return
        isSigning = true

        scope.launch {
            soundEffects.playUpgradeSweep(0.7f)
            delay(1200)

            val inputIds = selectedSkins.map { it.instanceId }
            val won = repository.executeContract(inputIds)
            selectedSkins.clear()
            isSigning = false

            if (won != null) {
                soundEffects.playUpgradeSuccess()
                contractResultSkin = won
            } else {
                soundEffects.playUpgradeFail()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("contracts_screen")
    ) {
        // Contract Parchment Card
        Card(
            colors = CardDefaults.cardColors(containerColor = BgCard),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, FlameGold, RoundedCornerShape(14.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.HistoryEdu,
                    contentDescription = null,
                    tint = FlameGold,
                    modifier = Modifier.size(44.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "КОНТРАКТ ОБМЕНА 10:1",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = FlameGold,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "Положите от 3 до 10 скинов, чтобы получить гарантированный скин более высокой редкости!",
                    fontSize = 11.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Slots for 10 items
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(10) { index ->
                            val skin = selectedSkins.getOrNull(index)
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BgDark)
                                    .border(
                                        1.dp,
                                        if (skin != null) skin.rarity.color else StrokeGlow,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        if (skin != null) selectedSkins.remove(skin)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (skin != null) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context)
                                            .data("file:///android_asset/${skin.assetPath}")
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = skin.fullName,
                                        modifier = Modifier.size(40.dp),
                                        contentScale = ContentScale.Fit
                                    )
                                } else {
                                    Text(
                                        text = "${index + 1}",
                                        fontSize = 11.sp,
                                        color = TextMuted,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Value and Items Count
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BgDark)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Выбрано: ${selectedSkins.size} / 10",
                        fontSize = 12.sp,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Сумма: ${if (totalContractValue >= 1000) String.format("%,.0f ₽", totalContractValue) else String.format("%.2f ₽", totalContractValue)}",
                        fontSize = 12.sp,
                        color = FlameGold,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { executeSignContract() },
                    enabled = selectedSkins.size in 3..10 && !isSigning,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FlameGold,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("sign_contract_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSigning) "ПОДПИСАНИЕ..." else "ПОДПИСАТЬ КОНТРАКТ",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Available Inventory items to add
        Text(
            text = "ВЫБЕРИТЕ ПРЕДМЕТЫ ИЗ ИНВЕНТАРЯ",
            fontWeight = FontWeight.Black,
            fontSize = 13.sp,
            color = TextPrimary,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        if (inventory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(BgCard),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Нет доступных предметов для контракта.",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        } else {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(inventory, key = { it.instanceId }) { skin ->
                    val isSelected = selectedSkins.any { it.instanceId == skin.instanceId }
                    Box(modifier = Modifier.width(110.dp)) {
                        SkinCard(
                            skin = skin,
                            isSelected = isSelected,
                            showSelectAction = true,
                            onClick = {
                                if (isSelected) {
                                    selectedSkins.removeAll { it.instanceId == skin.instanceId }
                                } else if (selectedSkins.size < 10) {
                                    selectedSkins.add(skin)
                                }
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Won from Contract Dialog
    contractResultSkin?.let { won ->
        Dialog(onDismissRequest = { contractResultSkin = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, won.rarity.color, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "КОНТРАКТ ВЫПОЛНЕН! 📜",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = NeonGreen
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data("file:///android_asset/${won.assetPath}")
                            .crossfade(true)
                            .build(),
                        contentDescription = won.fullName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size(110.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = won.fullName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )

                    Text(
                        text = "${won.rarity.title} • ${won.wear}",
                        fontSize = 11.sp,
                        color = won.rarity.color,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = won.displayPrice,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = FlameGold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { contractResultSkin = null },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FlameGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                    ) {
                        Text(
                            text = "ЗАБРАТЬ В ИНВЕНТАРЬ",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
