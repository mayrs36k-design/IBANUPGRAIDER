package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.audio.SoundEffects
import com.example.data.GameRepository
import com.example.model.CaseItem
import com.example.model.Rarity
import com.example.model.SkinItem
import com.example.ui.components.SkinCard
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardBorderHighlight
import com.example.ui.theme.CsBlue
import com.example.ui.theme.CsGold
import com.example.ui.theme.CsGoldDark
import com.example.ui.theme.CsRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun CaseOpenScreen(
    caseItem: CaseItem,
    repository: GameRepository,
    soundEffects: SoundEffects,
    onBack: () -> Unit,
    onNavigateToUpgradeWithSkin: (SkinItem) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var openCount by remember { mutableIntStateOf(1) }
    var isSpinning by remember { mutableStateOf(false) }
    var wonSkinsResult by remember { mutableStateOf<List<SkinItem>?>(null) }

    // Reel state
    val targetIndex = 48
    var reelItems by remember { mutableStateOf<List<SkinItem>>(emptyList()) }
    val reelOffsetX = remember { Animatable(0f) }

    fun startRoll(isFast: Boolean) {
        if (isSpinning) return

        val wins = repository.openCase(caseItem, count = openCount)
        if (wins.isEmpty()) {
            soundEffects.playUpgradeFail()
            return
        }

        if (isFast) {
            wonSkinsResult = wins
            soundEffects.playWinChime(wins.any { it.rarity == Rarity.SPECIAL || it.rarity == Rarity.COVERT })
            return
        }

        // Setup animated horizontal reel for the 1st won item
        val primaryWin = wins.first()
        val pool = caseItem.containedSkins
        val generatedList = mutableListOf<SkinItem>()
        for (i in 0 until 60) {
            if (i == targetIndex) {
                generatedList.add(primaryWin)
            } else {
                generatedList.add(pool[Random.nextInt(pool.size)])
            }
        }
        reelItems = generatedList

        isSpinning = true
        scope.launch {
            reelOffsetX.snapTo(0f)

            val itemPitchPx = 108f * context.resources.displayMetrics.density
            val jitter = (Random.nextFloat() * 40f - 20f)
            val finalTargetOffset = -(targetIndex * itemPitchPx) + jitter

            launch {
                val soundDelays = listOf(60L, 70L, 85L, 110L, 140L, 190L, 260L, 360L, 500L, 700L)
                for (d in soundDelays) {
                    delay(d)
                    soundEffects.playTick()
                }
            }

            reelOffsetX.animateTo(
                targetValue = finalTargetOffset,
                animationSpec = tween(
                    durationMillis = 3500,
                    easing = CubicBezierEasing(0.12f, 0.8f, 0.22f, 1f)
                )
            )

            delay(250)
            isSpinning = false
            wonSkinsResult = wins
            soundEffects.playWinChime(wins.any { it.rarity == Rarity.SPECIAL || it.rarity == Rarity.COVERT })
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 140.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .testTag("case_open_screen")
    ) {
        // Case Header Box & Roulette
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Header Row: Back Button & Case Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("case_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад к кейсам",
                            tint = CsGold
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = "${caseItem.category.lowercase()} кейс",
                            fontSize = 11.sp,
                            color = CsGoldDark,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "«${caseItem.name}»",
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = TextPrimary,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Case Display Box or Horizontal Spinning Reel
                if (isSpinning) {
                    // Roulette reel view (smooth 60fps)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BgCardElevated)
                            .border(1.dp, CardBorderHighlight, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier
                                .offset { IntOffset(reelOffsetX.value.toInt(), 0) }
                                .padding(horizontal = 140.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            reelItems.forEach { skin ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgCard),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .width(100.dp)
                                        .height(135.dp)
                                        .border(1.dp, skin.rarity.color.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data("file:///android_asset/${skin.assetPath}")
                                                .crossfade(false)
                                                .build(),
                                            contentDescription = skin.fullName,
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier.size(60.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = skin.weaponName,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = skin.skinName,
                                            fontSize = 8.sp,
                                            color = skin.rarity.color,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }

                        // Center indicator needle
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(150.dp)
                                .background(CsGold)
                        )
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .border(1.5.dp, CsGold, CircleShape)
                        )
                    }
                } else {
                    // Static Case Display
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .clip(CircleShape)
                            .background(BgCard)
                            .border(1.dp, CardBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data("file:///android_asset/${caseItem.assetPath}")
                                .crossfade(false)
                                .build(),
                            contentDescription = caseItem.name,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(135.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Multi-open count pills: 1, 2, 3, 5, 10
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Количество:",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontWeight = FontWeight.Bold
                    )
                    listOf(1, 2, 3, 5, 10).forEach { count ->
                        val isSelected = count == openCount
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) CsGold else BgCard)
                                .border(1.dp, if (isSelected) CsGold else CardBorder, RoundedCornerShape(6.dp))
                                .clickable { openCount = count }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("count_selector_$count")
                        ) {
                            Text(
                                text = "${count}x",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                color = if (isSelected) Color.Black else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Buttons
                val totalCost = caseItem.price * openCount
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Normal Open button
                    Button(
                        onClick = { startRoll(isFast = false) },
                        enabled = !isSpinning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CsGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("open_case_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Casino,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ОТКРЫТЬ (${String.format("%.0f", totalCost)} ₽)",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }

                    // Fast Open button
                    Button(
                        onClick = { startRoll(isFast = true) },
                        enabled = !isSpinning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BgCardElevated,
                            contentColor = CsGold
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .border(1.dp, CardBorderHighlight, RoundedCornerShape(8.dp))
                            .testTag("fast_open_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = CsGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "БЫСТРО (${String.format("%.0f", totalCost)} ₽)",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section title: СОДЕРЖИМОЕ КЕЙСА
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "СОДЕРЖИМОЕ КЕЙСА",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "${caseItem.containedSkins.size} скинов",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Case Items Grid
        items(caseItem.containedSkins, key = { it.id }) { skin ->
            SkinCard(
                skin = skin,
                onClick = {}
            )
        }
    }

    // Win Drop Modal Overlay
    wonSkinsResult?.let { wins ->
        Dialog(onDismissRequest = { wonSkinsResult = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CsGold, RoundedCornerShape(14.dp))
                    .testTag("win_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (wins.size > 1) "ВАШИ ВЫИГРЫШИ!" else "ПОЗДРАВЛЯЕМ!",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = CsGold,
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Display won skins
                    wins.take(3).forEach { wonSkin ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(BgDark)
                                .border(1.dp, wonSkin.rarity.color, RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data("file:///android_asset/${wonSkin.assetPath}")
                                        .crossfade(false)
                                        .build(),
                                    contentDescription = wonSkin.fullName,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(100.dp)
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = wonSkin.fullName,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = TextPrimary,
                                    textAlign = TextAlign.Center
                                )

                                Text(
                                    text = "${wonSkin.rarity.title} • ${wonSkin.wear}",
                                    fontSize = 11.sp,
                                    color = wonSkin.rarity.color,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = wonSkin.displayPrice,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = CsGold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    if (wins.size > 3) {
                        Text(
                            text = "+ еще ${wins.size - 3} предметов в инвентаре",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Action buttons
                    val primary = wins.first()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                wins.forEach { repository.sellSkin(it.instanceId) }
                                soundEffects.playCoinClick()
                                wonSkinsResult = null
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CsRed,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("sell_won_drop_button")
                        ) {
                            Text(
                                text = "ПРОДАТЬ ВСЁ",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = {
                                wonSkinsResult = null
                                onNavigateToUpgradeWithSkin(primary)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CsBlue,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("upgrade_won_drop_button")
                        ) {
                            Text(
                                text = "В АПГРЕЙД",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Button(
                        onClick = { wonSkinsResult = null },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BgCardElevated,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .testTag("keep_won_drop_button")
                    ) {
                        Text(
                            text = "ОСТАВИТЬ В ИНВЕНТАРЕ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
