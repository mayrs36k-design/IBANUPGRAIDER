package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CsGold,
    onPrimary = Color.Black,
    primaryContainer = BgCardElevated,
    onPrimaryContainer = Color.White,
    secondary = CsBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF1E2433),
    onSecondaryContainer = CsBlue,
    tertiary = CsGreen,
    onTertiary = Color.Black,
    background = BgDark,
    onBackground = TextPrimary,
    surface = BgCard,
    onSurface = TextPrimary,
    surfaceVariant = BgCardElevated,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    error = CsRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
