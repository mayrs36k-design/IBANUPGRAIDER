package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.audio.SoundEffects
import com.example.data.GameCatalog
import com.example.data.GameRepository
import com.example.model.Rarity
import com.example.model.SkinItem
import com.example.ui.components.SkinCard
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDark
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.FlameGold
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.StrokeGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun InventoryScreen(
    repository: GameRepository,
    soundEffects: SoundEffects,
    onNavigateToUpgrade: (SkinItem) -> Unit,
    onNavigateToFarm: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile by repository.profile.collectAsState()
    val inventory by repository.inventory.collectAsState()

    var selectedRarityFilter by remember { mutableStateOf<Rarity?>(null) }
    var selectedSkinDetail by remember { mutableStateOf<SkinItem?>(null) }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var showEditNameDialog by remember { mutableStateOf(false) }
    var newPlayerName by remember { mutableStateOf(profile.name) }

    val filteredInventory = remember(inventory, selectedRarityFilter) {
        if (selectedRarityFilter == null) inventory
        else inventory.filter { it.rarity == selectedRarityFilter }
    }

    val totalInventoryValue = remember(inventory) {
        inventory.sumOf { it.price }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 130.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .testTag("inventory_screen")
    ) {
        // Profile Header spanning all columns (Matching Frame 15 in Video)
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "ПРОФИЛЬ ИГРОКА",
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp,
                    color = FlameGold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                // Top 3-block profile dashboard: Stats | User Profile | Best Drop
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // LEFT: Account Stats
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgCard),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(170.dp)
                            .border(1.dp, StrokeGlow, RoundedCornerShape(10.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "СТАТИСТИКА",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = FlameGold
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Кейсов:", fontSize = 9.sp, color = TextMuted)
                                    Text(text = "${profile.casesOpened}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Апгрейдов:", fontSize = 9.sp, color = TextMuted)
                                    Text(text = "${profile.upgradesWon}/${profile.upgradesTotal}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Батлов:", fontSize = 9.sp, color = TextMuted)
                                    Text(text = "${profile.battlesWon}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonCyan)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Контрактов:", fontSize = 9.sp, color = TextMuted)
                                    Text(text = "${profile.contractsCompleted}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonPurple)
                                }
                            }
                        }
                    }

                    // CENTER: User Info & Avatar
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgCardElevated),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(170.dp)
                            .border(1.5.dp, NeonCyan, RoundedCornerShape(10.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Avatar with tap to change
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, NeonCyan, CircleShape)
                                    .clickable { showAvatarDialog = true }
                            ) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data("file:///android_asset/${profile.avatarAsset}")
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = profile.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { showEditNameDialog = true }
                            ) {
                                Text(
                                    text = profile.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Редактировать имя",
                                    tint = TextMuted,
                                    modifier = Modifier.size(12.dp)
                                )
                            }

                            Text(
                                text = profile.rankTitle,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = FlameGold
                            )

                            // Earn button matching video
                            Button(
                                onClick = onNavigateToFarm,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = FlameGold,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(30.dp)
                            ) {
                                Text(
                                    text = "ЗАРАБОТАТЬ",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // RIGHT: Best Drop
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgCard),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(170.dp)
                            .border(1.dp, StrokeGlow, RoundedCornerShape(10.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ЛУЧШИЙ ДРОП",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = FlameGold
                            )

                            val best = profile.bestDrop ?: inventory.maxByOrNull { it.price }
                            if (best != null) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data("file:///android_asset/${best.assetPath}")
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = best.fullName,
                                    modifier = Modifier.size(54.dp),
                                    contentScale = ContentScale.Fit
                                )
                                Text(
                                    text = best.fullName,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = best.rarity.color,
                                    maxLines = 1,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = best.displayPrice,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    color = FlameGold
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    text = "Откройте кейс!",
                                    fontSize = 9.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Inventory Value Bar & Fast Sell
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ВАШИ ПРЕДМЕТЫ (${inventory.size})",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = TextPrimary,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Общая стоимость: ${if (totalInventoryValue >= 1000) String.format("%,.0f ₽", totalInventoryValue) else String.format("%.2f ₽", totalInventoryValue)}",
                            fontSize = 11.sp,
                            color = FlameGold,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Fast Sell Commons Button
                    val commonCount = inventory.count { it.rarity == Rarity.COMMON || it.rarity == Rarity.UNCOMMON }
                    if (commonCount > 0) {
                        Button(
                            onClick = {
                                val gained = repository.sellAllByRarity(Rarity.COMMON, Rarity.UNCOMMON)
                                soundEffects.playCoinClick()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CrimsonRed.copy(alpha = 0.85f),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Слить ширп ($commonCount)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Rarity Filter Pills
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        val isAll = selectedRarityFilter == null
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isAll) NeonCyan else BgCard)
                                .border(1.dp, if (isAll) NeonCyan else StrokeGlow, RoundedCornerShape(16.dp))
                                .clickable { selectedRarityFilter = null }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "Все",
                                fontSize = 10.sp,
                                fontWeight = if (isAll) FontWeight.Bold else FontWeight.Medium,
                                color = if (isAll) Color.Black else TextSecondary
                            )
                        }
                    }

                    items(Rarity.entries) { r ->
                        val isSelected = selectedRarityFilter == r
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) r.color else BgCard)
                                .border(1.dp, r.color, RoundedCornerShape(16.dp))
                                .clickable { selectedRarityFilter = r }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = r.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.Black else r.color
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        // Inventory Items Grid
        if (filteredInventory.isEmpty()) {
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(BgCard),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "В этой категории нет предметов.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            items(filteredInventory, key = { it.instanceId }) { skin ->
                SkinCard(
                    skin = skin,
                    onClick = { selectedSkinDetail = skin }
                )
            }
        }
    }

    // Item Detail Action Modal
    selectedSkinDetail?.let { skin ->
        Dialog(onDismissRequest = { selectedSkinDetail = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, skin.rarity.color, RoundedCornerShape(16.dp))
                    .testTag("item_detail_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data("file:///android_asset/${skin.assetPath}")
                            .crossfade(true)
                            .build(),
                        contentDescription = skin.fullName,
                        modifier = Modifier.size(110.dp),
                        contentScale = ContentScale.Fit
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = skin.fullName,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "${skin.rarity.title} • ${skin.wear}",
                        fontSize = 11.sp,
                        color = skin.rarity.color,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = skin.displayPrice,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = FlameGold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Sell Button
                        Button(
                            onClick = {
                                repository.sellSkin(skin.instanceId)
                                soundEffects.playCoinClick()
                                selectedSkinDetail = null
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CrimsonRed,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                        ) {
                            Text(
                                text = "ПРОДАТЬ",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        // Upgrade Button
                        Button(
                            onClick = {
                                selectedSkinDetail = null
                                onNavigateToUpgrade(skin)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonPurple,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                        ) {
                            Text(
                                text = "В АПГРЕЙД",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { selectedSkinDetail = null },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BgCardElevated,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                    ) {
                        Text(
                            text = "ЗАКРЫТЬ",
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }

    // Avatar Chooser Dialog
    if (showAvatarDialog) {
        Dialog(onDismissRequest = { showAvatarDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .border(1.dp, StrokeGlow, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ВЫБЕРИТЕ АВАТАРКУ",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = FlameGold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(280.dp)
                    ) {
                        items(GameCatalog.avatarAssets) { av ->
                            Box(
                                modifier = Modifier
                                    .size(55.dp)
                                    .clip(CircleShape)
                                    .border(
                                        if (profile.avatarAsset == av) 2.dp else 1.dp,
                                        if (profile.avatarAsset == av) NeonCyan else StrokeGlow,
                                        CircleShape
                                    )
                                    .clickable {
                                        repository.updateAvatar(av)
                                        showAvatarDialog = false
                                    }
                            ) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data("file:///android_asset/$av")
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Edit Name Dialog
    if (showEditNameDialog) {
        Dialog(onDismissRequest = { showEditNameDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StrokeGlow, RoundedCornerShape(14.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ИЗМЕНИТЬ НИКНЕЙМ",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = FlameGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newPlayerName,
                        onValueChange = { newPlayerName = it.take(20) },
                        label = { Text("Никнейм") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showEditNameDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = BgCardElevated),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Отмена")
                        }

                        Button(
                            onClick = {
                                if (newPlayerName.isNotBlank()) {
                                    repository.updateProfileName(newPlayerName)
                                }
                                showEditNameDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FlameGold,
                                contentColor = Color.Black
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Сохранить")
                        }
                    }
                }
            }
        }
    }
}
