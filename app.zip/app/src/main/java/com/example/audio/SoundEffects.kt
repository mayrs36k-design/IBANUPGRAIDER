package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

class SoundEffects(context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private var soundEnabled = true
    private var hapticsEnabled = true

    fun setSoundEnabled(enabled: Boolean) { soundEnabled = enabled }
    fun isSoundEnabled(): Boolean = soundEnabled

    fun setHapticsEnabled(enabled: Boolean) { hapticsEnabled = enabled }
    fun isHapticsEnabled(): Boolean = hapticsEnabled

    fun playReelTick() {
        if (hapticsEnabled) triggerVibration(10, 80)
        if (!soundEnabled) return
        scope.launch {
            playTone(frequency = 1200f, durationMs = 18, amplitude = 0.35f)
        }
    }

    fun playTick() = playReelTick()

    fun playCoinClick() {
        if (hapticsEnabled) triggerVibration(15, 120)
        if (!soundEnabled) return
        scope.launch {
            playTone(frequency = 1600f, durationMs = 30, amplitude = 0.4f)
        }
    }

    fun playWinChime(isSpecial: Boolean = false) {
        if (hapticsEnabled) triggerVibration(if (isSpecial) 60 else 35, 200)
        if (!soundEnabled) return
        scope.launch {
            val freqs = if (isSpecial) {
                floatArrayOf(523.25f, 659.25f, 783.99f, 1046.50f, 1318.51f)
            } else {
                floatArrayOf(587.33f, 739.99f, 880.00f, 1174.66f)
            }
            for (f in freqs) {
                playTone(frequency = f, durationMs = 60, amplitude = 0.45f)
            }
        }
    }

    fun playUpgradeSweep(progressRatio: Float) {
        if (hapticsEnabled && (progressRatio * 100).toInt() % 15 == 0) {
            triggerVibration(12, 90)
        }
        if (!soundEnabled) return
        scope.launch {
            val f = 600f + progressRatio * 900f
            playTone(frequency = f, durationMs = 25, amplitude = 0.25f)
        }
    }

    fun playUpgradeSuccess() {
        if (hapticsEnabled) triggerVibration(80, 255)
        if (!soundEnabled) return
        scope.launch {
            val chord = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f)
            for (f in chord) {
                playTone(frequency = f, durationMs = 80, amplitude = 0.5f)
            }
        }
    }

    fun playUpgradeFail() {
        if (hapticsEnabled) triggerVibration(40, 100)
        if (!soundEnabled) return
        scope.launch {
            playTone(frequency = 220f, durationMs = 120, amplitude = 0.35f)
            playTone(frequency = 180f, durationMs = 150, amplitude = 0.35f)
        }
    }

    private fun triggerVibration(durationMs: Long, amplitude: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(
                        durationMs.coerceAtLeast(1),
                        amplitude.coerceIn(1, 255)
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    private fun playTone(frequency: Float, durationMs: Int, amplitude: Float) {
        try {
            val sampleRate = 22050
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt().coerceAtLeast(100)
            val buffer = ShortArray(numSamples)
            val decaySamples = (numSamples * 0.3).toInt()

            for (i in 0 until numSamples) {
                val time = i.toDouble() / sampleRate
                val raw = sin(2.0 * Math.PI * frequency * time)
                // Linear decay envelope to avoid clicks
                val envelope = if (i > numSamples - decaySamples) {
                    (numSamples - i).toDouble() / decaySamples
                } else 1.0
                buffer[i] = (raw * Short.MAX_VALUE * amplitude * envelope).toInt().toShort()
            }

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()
            Thread.sleep(durationMs.toLong() + 20)
            audioTrack.release()
        } catch (e: Exception) {
            Log.d("SoundEffects", "Tone failed: ${e.message}")
        }
    }
}
